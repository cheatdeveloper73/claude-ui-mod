const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["https://assets-proxy.anthropic.com/claude-ai/v2/assets/v1/shared-frame-BhEt6c-V.css","https://assets-proxy.anthropic.com/claude-ai/v2/assets/v1/shared-styles-JSe-PQAG.css"])))=>i.map(i=>d[i]);
import{Ba as e,Da as t,La as n,Oa as r,Sa as i,aa as a,da as o,ia as s,ja as c,oa as l,ra as u,za as d}from"./vendor-frame-CvMkXlR3.js";import{Ay as f,Dh as p,Ed as m,Gy as h,Hp as ee,P_ as g,Yd as _,ac as v,bd as y,gh as b,jy as x,lv as S,oc as C,qd as w,qs as T}from"./shared-common-0-BGMEEQm3.js";import{$l as E,En as te,Wn as D,br as ne,f_ as O,m_ as k,p_ as A,pn as j,yr as re}from"./shared-common-4-DhCvfoNu.js";import{t as M}from"./preload-helper-BWst14uo.js";import{Af as N,Nf as P,ar as ie,dr as F,fr as ae}from"./shared-3-C1vEAOxA.js";import{Ea as I,Fa as L,Qn as R,Za as z,ho as oe,nr as B}from"./shared-frame-DdWfvW_D.js";import{$a as se,c as V,l as ce}from"./shared-4-DKPmNySq.js";import{Cp as le,Su as ue,Ur as de,Yi as fe,Yl as pe,_s as H,eu as me,gu as he,ou as ge,ru as _e,sp as ve,zn as ye}from"./shared-common-5-gRg03EIa.js";import{Gi as be,Po as xe,Sa as Se,_f as Ce,b as we,df as Te,lf as Ee,sf as De,zf as Oe}from"./shared-2-GB8sG9uX.js";import{Eu as ke,Ih as Ae,Il as je,Js as Me,Ls as Ne,Nr as Pe,Pr as Fe,Vm as Ie,Vo as Le,Zm as Re,_c as ze,_h as Be,fg as Ve,gh as He,qh as U,rc as Ue,tr as We,ul as Ge}from"./shared-common-2-BliyRW9m.js";import{Qd as Ke,Yi as qe,cf as Je,er as Ye,oa as Xe}from"./shared-common-1-BXARzWg-.js";import{f as W,l as G,p as K}from"./vendor-intl-KLfag9z3.js";import{u as Ze}from"./c113cf5e7-DfyXvfF2.js";import{El as Qe,Ml as $e,Qc as et,Qt as tt,Rn as nt,Sl as rt,Xc as it,Zc as at,bl as ot,gl as st,pd as ct,xl as lt,yl as ut}from"./shared-13-b3JLvuah.js";import{Ba as dt,Fr as ft,Kr as pt,Mi as mt,Mr as ht,ri as gt}from"./shared-11-BNKeel3T.js";import{Ha as _t,Hi as vt,Up as yt,Va as bt,Vp as xt,c_ as St,dm as Ct,sg as wt}from"./shared-0-CIbzJMAO.js";import{it as Tt,mt as Et,pt as Dt}from"./shared-16-BVzTSvu-.js";import{Fc as Ot,Kc as kt,Vc as At,_c as jt,bc as Mt,hl as Nt,yc as Pt}from"./shared-14-ZTjt8COK.js";import{Md as Ft,ar as It,cu as Lt,xs as Rt,zd as zt}from"./shared-1-BRnjJFd5.js";import{Wr as Bt}from"./shared-10-DjPY-diQ.js";import{Sn as Vt,xn as Ht}from"./shared-7-CQ4qFy8E.js";import{Ka as Ut,Pa as Wt,fn as Gt}from"./shared-6-OxdjkPxj.js";import{Fo as Kt,Ia as qt,Io as Jt,No as q,On as Yt,Rr as Xt,bt as Zt,jn as Qt,jo as $t}from"./shared-5-Bk4fI6dN.js";import{ut as en}from"./shared-9-XPZFMTFT.js";import{ci as tn,ui as nn}from"./shared-15-CtNagRjL.js";import{t as rn}from"./cf793ae91-DROCxl2p.js";function an(){let[t,n]=e(!1);return c(()=>{let e=window.setTimeout(()=>n(!0),0);return()=>window.clearTimeout(e)},[]),t}var on={selectedFolders:[],selectedProjectUuids:new Set};function sn({disabled:e,deferred:t=!1}){let n=v(),r=y(),i=H(e=>e.pendingAutoSend?.source??null),a=st({source:i??"onboarding_chip"}),o=H(e=>e.pendingAutoSend?.status);c(()=>{if(o!=="staged")return;let i=H.getState(),s=i.pendingAutoSend;if(s?.status!=="staged")return;if(e){i.clearPendingAutoSend();return}if(t||!Ve(window.location.pathname))return;if(q.getState().vmDownloadError){i.clearPendingAutoSend();return}i.markPendingAutoSendFiring();let c=H.getState().pendingAutoSend,l,u=!1,d=()=>{let e=window.location.pathname;return e===U||e===`${U}/`||l!==void 0&&e===`/cowork/${l}`},f=q.subscribe(e=>{!e.vmDownloadError||u||(u=!0,f(),l&&ze(Ge({kind:"cowork",id:l})))});a({prompt:s.prompt,title:s.title,draftSelections:on,...r?{skipRedirect:!0,onOptimisticId:e=>{l=e,n.push(`${Ae}/${e}`)}}:{onDraftHandBack:T}}).then(e=>{if(!u){if(!e){r&&d()&&n.replace(U);return}s.onStarted?.(e),r&&e!==l&&d()&&n.replace(`${Ae}/${e}`)}}).catch(()=>{r&&!u&&d()&&n.replace(U)}).finally(()=>{f();let e=H.getState();e.pendingAutoSend===c&&e.clearPendingAutoSend()})},[o,e,t,a,n,r]);let s=d(!0);return c(()=>(s.current=!0,()=>{s.current=!1,queueMicrotask(()=>{if(s.current)return;let e=H.getState();e.pendingAutoSend?.status==="staged"&&e.clearPendingAutoSend()})}),[]),null}var cn={lineHeight:1.5,fontSize:"clamp(1.875rem, 1.2rem + 2vw, 2.5rem)"};function ln(){return l("h1",{className:"font-display text-secondary -ml-2 text-balance text-center",style:cn,children:[a(R,{className:"mr-[0.35em] inline-block h-[0.8em] w-[0.8em] align-[-0.075em]"}),a(G,{defaultMessage:"Let\u2019s knock something off your list.",id:"NUs72amU1j"})]})}var un="first-skill-uploaded-2025-09-30";function dn(){let{nuxSkillName:e}=en(ke(e=>({nuxSkillName:e.nuxSkillName}))),t=K(),{isDismissed:n}=Rt(),r=n(un),i=V(),{promptInputRef:o}=Lt(),{setPrompt:s}=Ft(e=>({setPrompt:e.setPrompt})),u=d(null),f=d(!1);return c(()=>{if(!e||f.current||r||i)return;let n=t.formatMessage({defaultMessage:"Hey Claude\u2014I just added the \u201C{nuxSkillName}\u201D skill. Can you make something amazing with it?",id:"MBjQlaEqUX"},{nuxSkillName:e}),a=setInterval(()=>{if(o?.current){f.current=!0;let e=o.current.getEditor();e?.isEmpty&&(e.chain().focus().setContent(n).run(),s(n)),clearInterval(a)}},100),c=setTimeout(()=>{clearInterval(a)},5e3);return()=>{clearInterval(a),clearTimeout(c)}},[e,r,i,s,o,t]),l("div",{className:"relative",children:[a("div",{ref:u,className:"absolute -top-2 left-[33px] w-0 h-0"}),a(Pt,{canShowNux:!!e,anchorRef:u,side:"top",align:"start",ariaLabel:t.formatMessage({defaultMessage:"Try your skill",id:"DBx5VLr/ru"}),text:a(G,{defaultMessage:"Claude can use skills in any chat. Mention it to try it out\u2014you don\u2019t even need to use the exact name.",id:"6ku8vR1894"}),id:un,nuxItem:{dateAdded:"2025-09-30",priority:ce.HIGH,showAfterOthersDismiss:!1}})]})}var fn=nn.spotlight.reopenParam,pn=nn.spotlight.roundtripKey,mn={mode:"live",entry:"spotlight",arm:"composer",reopenQuery:`${fn}=1`,oauthReturnPathname:"/task/new"};function hn(){let t=C(),[n]=h(()=>{if(!t.has(fn))return!1;try{return sessionStorage.getItem(pn)==="1"}catch{return!1}},!1),[r,i]=e(!1);return!n||r?null:a(pe,{componentName:"SpotlightMorningBriefResume",fallback:null,children:a(tn,{open:!0,...mn,resumeAtConnect:!0,onClose:()=>{try{sessionStorage.removeItem(pn)}catch{}i(!0)}})})}var gn="cowork-guest-pass-home",_n=2,vn="claudeai.cowork.guest_pass_section";function yn({remainingPasses:e,totalPasses:t,formattedRewardAmount:n,onDismiss:r,onCopyLink:i,didCopy:o,referralLink:s}){let u=Ye(),d=w("guest_passes","cowork_enabled",!1,m);if(c(()=>{d&&u.track({event_key:`${vn}.shown`})},[d,u]),!d)return null;let f=_e(s);return l("section",{className:"w-full max-w-2xl mt-8 group/guest-pass",children:[l("div",{className:"flex items-center justify-between mb-2 px-2",children:[a("span",{className:"font-small text-muted",children:a(G,{defaultMessage:"Guest pass",id:"ZteiJB+wqW"})}),a("button",{onClick:r,"aria-label":"Dismiss guest pass",className:"text-muted hover:text-secondary transition-colors opacity-0 group-hover/guest-pass:opacity-100",children:a(Ie,{size:16})})]}),l("div",{className:"flex items-start gap-4 px-2 py-3 rounded-lg",children:[a("div",{className:"flex-shrink-0",children:l("div",{className:"rounded-xl overflow-hidden bg-surface-0 p-2 w-fit border-[0.29px] border-strong",children:[a("div",{className:"bg-surface-3 rounded-lg p-2 mb-1",children:a("div",{className:"flex items-center justify-center",children:a(ye,{name:"ObjectGiftTag",size:56,className:"text-primary"})})}),a("span",{className:"font-small text-muted px-0.5",children:a(G,{defaultMessage:"{remaining}/{total} left",id:"T5gc7oC58K",values:{remaining:e,total:t}})})]})}),l("div",{className:"flex-1 min-w-0 flex flex-col gap-1",children:[a("span",{className:"font-base text-primary",children:a(G,{defaultMessage:"Gift a week of Cowork",id:"G0hew2N8Cs"})}),a("span",{className:"font-small text-secondary",children:n?a(G,{defaultMessage:"Send a friend a free week of Cowork. If they love it and subscribe, you\u2019ll get {rewardAmount} in usage credits. <termsLink>Terms apply</termsLink>",id:"4XNfB5Ko70",values:{rewardAmount:n,termsLink:e=>a(I,{href:"https://support.claude.com/en/articles/13456702-claude-code-guest-passes",external:!0,rel:"noopener noreferrer",children:e})}}):a(G,{defaultMessage:"Send a guest pass to a friend. They\u2019ll get a free week to try Cowork. <termsLink>Terms apply</termsLink>",id:"V6+nefylmL",values:{termsLink:e=>a(I,{href:"https://support.claude.com/en/articles/12875061-claude-code-guest-passes",external:!0,rel:"noopener noreferrer",children:e})}})}),a("div",{className:"mt-3",children:a(L,{variant:"secondary",onClick:()=>i(f),children:o?a(G,{defaultMessage:"Copied!",id:"0oL1zz+YDx"}):a(G,{defaultMessage:"Copy invite",id:"7EQovv70UM"})})})]})]})]})}function bn(){let e=Ye(),r=K(),{addSuccess:i}=Le(),{copyToClipboard:o,didCopy:s}=de(),c=ct()?"/settings/account":"/settings/cowork",l=E(c),u=_("cowork_referrals"),d=he(),f=Ue(),p=Me(),m=f&&p.length>=_n,{dismiss:h,isDismissed:ee}=Rt(),g=ee(gn),{data:v,isLoading:y}=re(me.CLAUDE_CODE_GUEST_PASS,"cowork",{enabled:u&&!g&&m}),b=v?.referral_code_details,{data:x}=ne(b?.campaign??me.CLAUDE_CODE_GUEST_PASS,{enabled:!!b}),S=x?Math.max(0,x.limit-x.used):0,C=x?.limit??0,w=n(()=>{let e=v?.referral_code_details?.referral_link;if(e)return ge(e)},[v?.referral_code_details?.referral_link]),T=n(()=>{let e=v?.referrer_reward;if(!e)return null;let t=e.amount_minor_units/100;return r.formatNumber(t,{style:"currency",currency:e.currency,minimumFractionDigits:0,maximumFractionDigits:0})},[v?.referrer_reward,r]),te=v?.eligible??!1,D=t(t=>{o(t),e.track({event_key:`${vn}.copy_clicked`})},[o,e]),O=t(()=>{h(gn),i(a(G,{defaultMessage:"You can get your guest pass invite link in {settingsLink}.",id:"uL56zzNFPD",values:{settingsLink:a(I,{href:c,onClick:l,children:a(G,{defaultMessage:"Settings",id:"D3idYvSLF9"})})}}),{timeout:1e4}),e.track({event_key:`${vn}.dismissed`})},[e,i,h,l,c]);return!u||d||!m||g||y||!te||S<=0||!w?null:a(yn,{remainingPasses:S,totalPasses:C,formattedRewardAmount:T,onDismiss:O,onCopyLink:D,didCopy:s,referralLink:w})}var xn=!1,Sn=!0,Cn=O(()=>M(()=>import("./shared-16-BVzTSvu-.js").then(e=>e.at).then(e=>({default:e.CommsThumbnail})),__vite__mapDeps([0,1]),import.meta.url)),wn=O(()=>M(()=>import("./shared-16-BVzTSvu-.js").then(e=>e.at).then(e=>({default:e.DocThumbnail})),__vite__mapDeps([0,1]),import.meta.url)),Tn=O(()=>M(()=>import("./shared-16-BVzTSvu-.js").then(e=>e.at).then(e=>({default:e.FileThumbnail})),__vite__mapDeps([0,1]),import.meta.url)),En=O(()=>M(()=>import("./shared-16-BVzTSvu-.js").then(e=>e.at).then(e=>({default:e.OrganizeThumbnail})),__vite__mapDeps([0,1]),import.meta.url)),J=O(()=>M(()=>import("./shared-16-BVzTSvu-.js").then(e=>e.at).then(e=>({default:e.PrepThumbnail})),__vite__mapDeps([0,1]),import.meta.url)),Dn=O(()=>M(()=>import("./shared-16-BVzTSvu-.js").then(e=>e.at).then(e=>({default:e.SkillThumbnail})),__vite__mapDeps([0,1]),import.meta.url)),On=O(()=>M(()=>import("./shared-16-BVzTSvu-.js").then(e=>e.at).then(e=>({default:e.SpreadsheetThumbnail})),__vite__mapDeps([0,1]),import.meta.url)),kn=3,An="cowork-suggestions",Y=W({hideSuggestions:{defaultMessage:"Hide suggestions",id:"8/jokSbxkH"},initialName:{defaultMessage:"Pick a task, any task",id:"OnaQpdV9zK"},organizeName:{defaultMessage:"Tidy up and get organized",id:"Wi8J5SkAVq"},prepName:{defaultMessage:"Plan for what\u2019s ahead",id:"OSqbaQv7nr"},dataName:{defaultMessage:"Turn messy data into action",id:"CiHCdg7mGP"}}),X=W({label1:{defaultMessage:"Optimize my week",id:"ov1AuKcjep"},prompt1:{defaultMessage:`Help me plan and optimize my week. I have my Google Calendar open and ready for you to review and edit.

First, review my calendar and show me a summary:
- Total meetings
- Busiest days
- Where I have gaps of 2+ hours

Before proposing changes, ask me about:
- What I\u2019m trying to accomplish this week
- How much focus time I need and for what
- Any deadlines or commitments not on my calendar
- Which types of meetings I should decline or shorten
- Personal commitments or boundaries I want to protect

Then show me your top 3-5 proposed changes with explanations:
- Focus blocks to add
- Meetings to decline or reschedule
- Time conflicts to resolve

Start with the highest-impact changes first. Once I approve each change, make the edits directly in my calendar one at a time.`,id:"BP5Dk3Ob1V"},label2:{defaultMessage:"Organize my screenshots",id:"R9OYtL0hxN"},prompt2:{defaultMessage:`Help me organize recent screenshots on my Desktop.

First, scan my Desktop and count how many screenshots/images are there. Show me:
- Total count
- Date range (oldest to newest)

Then, focus only on screenshots from the last 14 days. For each one:
- Identify what it shows
- Suggest a descriptive filename
- Propose which folder it belongs in (or if it can be deleted)

Group similar screenshots together. Show me the plan before making any changes.

After I approve, start by organizing just 10 files as a preview. If there are more than 10 files, check in with me before continuing with the rest.`,id:"gf8CwL7i2S"},label3:{defaultMessage:"Find insights in files",id:"JDTaxC6dOy"},prompt3:{defaultMessage:`Help me find patterns and insights across [my voice memos / meeting transcripts / documents / journal entries / specify folder]. I have messy, unstructured files and want to understand what themes are emerging.

First, scan the folder and show me a summary:
- Total files
- Date range (oldest to newest)
- Types of content

Before analyzing, ask me:
- What I\u2019m hoping to discover (recurring themes, contradictions, evolution of thinking, action items, or something else)
- Whether certain files or time periods should be prioritized
- What format would be most useful for the final analysis

If there are more than 20 files, start by analyzing just the 10 most recent files.

Show me the top 3-5 patterns you found with 2-3 specific examples for each pattern. Once I confirm you\u2019re on the right track, analyze the remaining files.`,id:"NYXDxDr/pR"}}),Z=W({downloadsLabel:{defaultMessage:"Clean up my Downloads folder",id:"+jEI/ChslN"},downloadsPrompt:{defaultMessage:`Help me organize my Downloads folder.

First, scan and show me a summary:
- Total files and total size
- Files older than 30 days
- Largest files taking up space

Before organizing, ask me:
- What categories or folder structure would be most useful
- Whether I want to delete or archive old files
- If there are specific file types I want to prioritize (documents, images, installers, etc.)

Then focus only on files older than 30 days first. Show me a proposed plan for these old files:
- Categories to create
- Files to delete (installers, duplicates, temp files)
- Files to keep with where they should go

After I approve, organize the first 15 old files as a preview. If there are more files, check in before continuing.`,id:"rwHbOEDVZV"},photosLabel:{defaultMessage:"Organize photos by event/date",id:"MHWdx0dF9s"},photosPrompt:{defaultMessage:`Help me organize photos on my [Desktop/Downloads/specify location].

First, scan the folder and show me a summary:
- Total photos
- Date range (oldest to newest)
- Rough size breakdown

Before organizing, ask me:
- How I\u2019d like them organized (by date, by event, by person)
- Whether there are specific events or time periods I should know about
- What folder structure would work best
- If any photos can be deleted (duplicates, blurry ones, screenshots)

Focus only on photos from the last 3 months first. Show me a proposed plan with examples from 3-4 different groups so I can show you how I\u2019d organize them.

After I approve, organize just 20 photos as a preview. If there are more than 20, check in before continuing with the rest.`,id:"lyqodEFYUz"},inboxLabel:{defaultMessage:"Organize my inbox",id:"ZIlEIwm/xI"},inboxPrompt:{defaultMessage:`Help me organize and clean up my email inbox.

First, scan my inbox and show me a summary:
- Total unread emails
- Emails older than 30 days
- The main senders or types of emails

Before organizing, ask me:
- What categories or folders I want to create
- Which types of emails I want to archive or delete
- Whether there are specific senders I want to prioritize or filter
- Any email patterns I want to address (newsletters, promotions, etc.)

Focus only on emails older than 30 days first \u2014 these are easiest to clean up. Show me a proposed plan:
- Which emails to archive
- Which to delete
- Which need action

If there are more than 50 old emails, start with a batch of 20 so I can check your approach. Once I approve, process that batch.`,id:"uSagFPkSjM"}}),Q=W({meetingLabel:{defaultMessage:"Prep for my next meeting",id:"QHlNmNrDvS"},meetingPrompt:{defaultMessage:`I have a meeting with [a company] [tomorrow].

Before researching, ask me:
- What the meeting is about
- What I already know about them
- What I\u2019m trying to accomplish
- What would be most useful to know going in

Then research them and show me what you found:
- Company overview
- Recent news (last 3 months)
- Key people I\u2019ll be meeting with
- Their LinkedIn for recent updates

Show me an outline of the one-pager with the 3-5 most important points before writing the full doc. Once I approve, create the final one-pager.`,id:"/ci4wyJ3UA"},vacationLabel:{defaultMessage:"Plan my next vacation",id:"25FqIz63Gl"},vacationPrompt:{defaultMessage:`Help me plan my next vacation.

Before researching, ask me:
- Where I\u2019m thinking of going (or if I\u2019m open to suggestions)
- When I want to travel and for how long
- What my budget is
- What kind of trip I\u2019m looking for (relaxing, adventure, cultural, food-focused, etc.)

Then research the top 3 destinations that fit my criteria and show me a comparison:
- Estimated costs
- Best time to visit
- What makes each unique

Once I pick my top choice, research that destination in detail:
- Check current flight prices
- Find 3-4 accommodation options
- Suggest a day-by-day outline

Show me this proposed itinerary with estimated costs before creating the final trip plan.`,id:"HuqKX9Lq0c"},interviewLabel:{defaultMessage:"Prepare for a job interview",id:"ZZs+9RvBit"},interviewPrompt:{defaultMessage:`I have a job interview coming up for [role] at [company].

Before researching, ask me:
- What the role is and what level
- What I already know about the company
- What I\u2019m most nervous or uncertain about
- If I have the job description or any interview details

Then research the company and role, and show me what I found:
- Company overview and recent news (last 6 months)
- What this role typically involves
- Common interview questions for this type of role
- The interview team on LinkedIn (if you have names)

Show me an outline covering these 3-5 topics before creating the full prep doc:
- Key points about the company to mention
- How my background connects to what they need
- Questions I should ask them
- 3-4 likely interview questions with suggested talking points

Once I approve, create a complete interview prep guide I can review before the interview.`,id:"WGyPATTkEY"}}),$=W({slackLabel:{defaultMessage:"Catch me up on Slack",id:"d9nxSkZHNk"},slackPrompt:{defaultMessage:`Help me catch up on what I\u2019ve missed in Slack.

Before reading, ask me:
- Which channels or DMs I should focus on (or check everything)
- How far back to look (since yesterday, last week, specific date)
- What I\u2019m most concerned about missing (decisions, @mentions, urgent items, project updates)
- Whether there are specific topics or people to prioritize

Then scan those channels and show me a summary:
- Total unread messages
- Breakdown by channel

Focus on messages that @mention me, contain decisions, or are marked urgent first.

Show me the top 5 most important updates with context and links to the threads. If there are more than 30 unread messages total, start with these top 5 and ask if you should summarize more.`,id:"utm8b0Qm7L"},voiceMemosLabel:{defaultMessage:"Turn voice memos into a doc",id:"a98wK30fJF"},voiceMemosPrompt:{defaultMessage:`Help me turn my voice memos into an organized document. I have [voice memos / audio recordings] in [specify location] that I want transcribed and organized.

First, scan the folder and show me:
- How many audio files
- Total duration
- Date range

Before transcribing, ask me:
- What these recordings are about
- How I\u2019d like them organized (chronologically, by topic, by theme)
- Whether I want verbatim transcripts or cleaned-up summaries
- What the final document should be (meeting notes, journal entries, ideas list, etc.)

If there are more than 5 recordings, start by transcribing just the 3 most recent ones. Show me the transcribed content and proposed organization structure.

Once I approve the approach, transcribe and organize the remaining recordings.`,id:"iQaqJcOvkA"},spreadsheetLabel:{defaultMessage:"Pull data into a spreadsheet",id:"qgNJFeupXW"},spreadsheetPrompt:{defaultMessage:`I\u2019m on a page with [job listings / products / directory entries] I want to extract.

First, scan the page and show me what you see:
- How many items total
- What fields are available (title, price, location, description, etc.)

Before extracting, ask me:
- Which fields I want in the spreadsheet
- If there are any I should skip

Then show me a preview with the first 3-5 items extracted so I can confirm the format looks right.

If there are more than 20 items on this page, extract them in batches of 10. If there are multiple pages, just do the first page and check with you before continuing.`,id:"sXOkVOa9tv"}}),jn=[{id:"initial",name:Y.initialName,prompts:[{id:"initial-1",label:X.label1,fullPrompt:X.prompt1,thumbnail:J},{id:"initial-2",label:X.label2,fullPrompt:X.prompt2,thumbnail:En,systemFolder:"desktop"},{id:"initial-3",label:X.label3,fullPrompt:X.prompt3,thumbnail:Tn}]},{id:"organize",name:Y.organizeName,prompts:[{id:"organize-downloads",label:Z.downloadsLabel,fullPrompt:Z.downloadsPrompt,thumbnail:En,systemFolder:"downloads"},{id:"organize-photos",label:Z.photosLabel,fullPrompt:Z.photosPrompt,thumbnail:En},{id:"organize-inbox",label:Z.inboxLabel,fullPrompt:Z.inboxPrompt,thumbnail:Cn}]},{id:"prep",name:Y.prepName,prompts:[{id:"prep-meeting",label:Q.meetingLabel,fullPrompt:Q.meetingPrompt,thumbnail:J},{id:"prep-vacation",label:Q.vacationLabel,fullPrompt:Q.vacationPrompt,thumbnail:J},{id:"prep-interview",label:Q.interviewLabel,fullPrompt:Q.interviewPrompt,thumbnail:J}]},{id:"data",name:Y.dataName,prompts:[{id:"data-slack",label:$.slackLabel,fullPrompt:$.slackPrompt,thumbnail:Cn},{id:"data-voice-memos",label:$.voiceMemosLabel,fullPrompt:$.voiceMemosPrompt,thumbnail:wn},{id:"data-spreadsheet",label:$.spreadsheetLabel,fullPrompt:$.spreadsheetPrompt,thumbnail:On}]}];function Mn({prompt:e,onSelect:t}){let n=K(),r=e.thumbnail;return l("button",{onClick:()=>t(e),className:u("w-full flex items-center gap-3 px-2 py-3","transition-colors hover:bg-neutral-30 hover:rounded-lg","group text-left"),children:[a("div",{className:"flex-shrink-0 w-10 h-10 flex items-center justify-center",children:r?a(r,{}):null}),a("div",{className:"flex-1 min-w-0",children:a("span",{className:"font-base text-secondary",children:n.formatMessage(e.label)})}),a(He,{size:16,className:"hidden group-hover:block flex-shrink-0 text-muted"})]})}function Nn({item:e,displayName:t,loading:n,onSelect:r}){let i=_t(e.name),o=t??`/${i}`;return l("button",{onClick:()=>r(e),className:u("w-full flex items-center gap-3 px-2 py-3","transition-colors hover:bg-surface-0 hover:rounded-lg","group text-left"),children:[a("div",{className:"flex-shrink-0 w-10 h-10 flex items-center justify-center",children:a(Dn,{})}),a("div",{className:"flex-1 min-w-0",children:a("span",{className:"text-sm text-secondary",children:n?a(te,{variant:"secondary",children:o}):o})}),a(He,{size:16,className:"hidden group-hover:block flex-shrink-0 text-muted"})]})}function Pn(){let r=K(),{isEnabled:i}=St(),{setPrompt:s,promptInputRef:u}=Ft(e=>({setPrompt:e.setPrompt,promptInputRef:e.promptInputRef})),{trackAgentModeEvent:f}=Tt(),p=Me(),m=Ue(),{dismiss:h,isDismissed:ee}=Rt(),g=ee(An),{data:_,isLoading:v}=Ct(),y=n(()=>_.filter(e=>!e.enabled||yt(e)?!1:e.skills.filter(xt).length>0),[_]),b=!v&&y.length>0,[x,C]=e(null),w=n(()=>y.find(e=>e.id===x)??y[0]??null,[y,x]),[T]=e(()=>Date.now()%2147483646+1),E=n(()=>{if(!w)return[];let e=w.skills.filter(xt).map(e=>({name:e.name,description:e.description,argumentHint:e.argumentHint})),t=e=>{let t=T;for(let n=e.length-1;n>0;n--){t=t*16807%2147483647;let r=Math.floor((t-1)/2147483646*(n+1));[e[n],e[r]]=[e[r],e[n]]}return e},n=e.filter(e=>e.argumentHint),r=e.filter(e=>!e.argumentHint);return[...t([...n]),...t([...r])].slice(0,kn)},[w,T]),te=n(()=>E.map(e=>({name:e.name,description:e.description??"",pluginName:w?.name})),[E,w?.name]),{displayNames:D,isSettled:ne}=It(te),O=n(()=>w?w.displayName||wt(bt(w.name)):null,[w]),[k,A]=e(0),j=n(()=>jn[k],[k]),re=!g&&m&&!v&&!b&&p.length<=3,M=j.id,N=j.prompts,P=d(new Set),ae=re?`${M}:${N.map(e=>e.id).join(",")}`:null;c(()=>{if(ae)for(let e of N)P.current.has(e.id)||(P.current.add(e.id),f("prompt_shown",{prompt_id:e.id,category:M,source:"suggestion_list"}))},[ae,N,M,f]);let I=t(()=>{let e=(k+1)%jn.length;f("nudge_clicked",{from_category:j.id,to_category:jn[e].id,source:"shuffle_button"}),A(e)},[k,j.id,f]),R=t(()=>{h(An)},[h]),z=ie(),se=Sn,V=Se(),ce=t(()=>{f("browse_more_opened",{source:"suggestion_list"}),z({section:"plugins"})},[f,se,z,V]),le=t(e=>{f("prompt_clicked",{prompt_id:e.id,category:M,source:"suggestion_list"}),s(r.formatMessage(e.fullPrompt),{forceUpdateTiptap:!0}),u&&setTimeout(()=>{u.current?.focus()},50)},[M,f,s,u,r]),ue=t(e=>{f("skill_selected",{skill_name:S,source:"suggestion_list"});let t=u?.current?.getEditor();if(!t)return;let n=t.storage["slash-command-suggestion"];n&&(n.justClosed=!0,setTimeout(()=>{n.justClosed=!1},300));let r=_t(e.name),i=F(e.name,r,e.description??"",e.argumentHint??"");t.chain().focus().setContent({type:"paragraph",content:i}).run()},[f,u]);return g||!m?null:b&&w?l("section",{className:"w-full max-w-2xl mt-8 group/suggestions",children:[l("div",{className:"flex items-center justify-between mb-2 px-2",children:[l("div",{className:"flex items-center gap-1 font-small text-muted",children:[a(G,{defaultMessage:"Get to work with",id:"inbT+cAasq"}),l(B.Root,{children:[a(B.Trigger,{render:l("button",{className:"flex items-center gap-1 font-small-bold hover:text-primary transition-colors",children:[a("span",{children:O}),a(Be,{size:12})]})}),a(oe,{density:"compact",className:"contents",children:l(B.Popup,{children:[a(B.Group,{children:y.map(e=>a(B.Item,{icon:"Plugin",checked:e.id===w.id,checkedRole:"radio",onClick:()=>C(e.id),children:e.displayName||wt(bt(e.name))},e.id))}),a(B.Separator,{}),a(B.Item,{onClick:()=>V("/customize/plugins"),children:a(G,{defaultMessage:"Manage plugins",id:"EXoZxGhXPy"})})]})})]})]}),a("button",{onClick:R,"aria-label":r.formatMessage(Y.hideSuggestions),className:"text-muted hover:text-secondary transition-colors opacity-0 group-hover/suggestions:opacity-100",children:a(Ie,{size:16})})]}),a("div",{className:"flex flex-col [&>button:hover+hr]:opacity-0 [&>hr:has(+button:hover)]:opacity-0",children:E.map((e,t)=>l(o,{children:[a(Nn,{item:e,displayName:D.get(e.name),loading:!ne&&!D.get(e.name),onSelect:ue}),t<E.length-1&&a("hr",{className:"border-t-0.5 mx-2 transition-opacity"})]},e.name))}),a(Ke,{href:`/customize/plugins/${encodeURIComponent(w.id)}`,onClick:e=>{e.button!==0||e.metaKey||e.ctrlKey||e.shiftKey||e.altKey||(e.preventDefault(),V(`/customize/plugins/${encodeURIComponent(w.id)}`))},className:"font-small text-muted hover:text-secondary transition-colors mt-2 ml-2",children:a(G,{defaultMessage:"See all",id:"078WAre0KU"})})]}):p.length>3||v?null:l("section",{className:"w-full max-w-2xl mt-8 group/suggestions",children:[l("div",{className:"flex items-center justify-between mb-2 px-2",children:[l("button",{onClick:I,className:"flex items-center gap-2 font-small text-muted hover:text-primary transition-colors",children:[a(Ze,{size:20}),a("span",{children:r.formatMessage(j.name)})]}),a("button",{onClick:R,"aria-label":r.formatMessage(Y.hideSuggestions),className:"text-muted hover:text-secondary transition-colors opacity-0 group-hover/suggestions:opacity-100",children:a(Ie,{size:16})})]}),a("div",{className:"flex flex-col [&>button:hover+hr]:opacity-0 [&>hr:has(+button:hover)]:opacity-0",children:N.map((e,t)=>l(o,{children:[a(Mn,{prompt:e,onSelect:le}),t<N.length-1&&a("hr",{className:"border-t-0.5 mx-2 transition-opacity"})]},e.id))}),(i||xn)&&a(L,{variant:"ghost",onClick:ce,className:"mt-1",children:a(G,{defaultMessage:"Customize with plugins",id:"i2yl4bVuRw"})})]})}var Fn=i(function({surface:n,className:r}){let i=y(),[o,c]=e(!1),u=t(()=>c(!0),[]),d=t(()=>c(!1),[]);return i?l(s,{children:[a(L,{variant:"ghost",size:"xs",onClick:u,className:r,children:a(G,{defaultMessage:"What\u2019s new",id:"m/7Y4kJLsg"})}),a(tt,{isOpen:o,onClose:d,surface:n})]}):null});function In(e){let{kind:t,sessionId:n,enabled:r=!0}=e;c(()=>{r&&p?.signalSessionIntent?.({kind:t,sessionId:n??null})},[t,n,r])}var Ln=75;function Rn(){let n=d(!1),r=d(!1),i=Jt(),a=q(e=>e.vmRunningStatus),o=q(e=>e.vmDownloadStatus),s=q(e=>e.vmDownloadProgress),l=!!b?.showNotification&&i&&(o==="downloading"||o==="not_downloaded")&&s<Ln,[u,f]=e("armed"),p=u;p==="armed"&&l&&(p="open"),p==="open"&&a==="ready"&&(p="closed"),p!==u&&f(p),c(()=>{a==="ready"&&n.current&&!r.current&&(r.current=!0,zn())},[a]);let m=t(()=>{n.current=!0,f(e=>e==="open"?"closed":e),q.getState().vmRunningStatus==="ready"&&!r.current&&(r.current=!0,zn())},[]),h=t(()=>{f(e=>e==="open"?"closed":e)},[]);return{showModal:p==="open",requestNotification:m,dismiss:h}}async function zn(){if(b?.showNotification)try{let e=await b.getAuthorizationStatus?.();if(e==="notDetermined"){if(await b.requestAuthorization?.()!=="granted")return}else if(e==="denied")return;await b.showNotification("Ready to go","Claude's all set up and working on your task right now.","vm-ready")}catch(e){x.warn(f.LOCAL_SESSION,"Failed to send VM ready notification",{error:e})}}var Bn=!1,Vn=A({entry:{id:"slow_vm_download_modal",tier:"T3",load:()=>M(()=>import("./c518dd2d1-ROQ2pArH.js"),__vite__mapDeps([0]),import.meta.url)},pick:e=>e.SlowVMDownloadModal,options:{ssr:!1,loading:k("frame-inside-chunk")}}).Component;function Hn(t){let[n,r]=e(t.isOpen);return t.isOpen&&!n&&r(!0),n?a(Vn,{...t}):null}var Un=A({entry:{id:"cowork_egress_banner",tier:"T3",load:()=>M(()=>import("./c61a016df-BFePnef2.js"),__vite__mapDeps([0,1]),import.meta.url)},pick:e=>e.CoworkEgressBanner,options:{ssr:!1,loading:()=>a("div",{className:"mx-auto mb-3 w-full max-w-2xl",children:a(Ce,{height:112,className:"rounded-card"})})}}).Component,Wn="https://support.claude.com/en/articles/13364135-use-claude-cowork-safely";function Gn(){let e=Fe(),t=y(),n=Ue(),{isLoading:r}=Pe();return!(t&&(e.loading||r))&&n}function Kn({centered:e}){let n=Fe(),r=ht(),i=ft(),o=t(()=>{i({source:"agent_new_page"})},[i]);return n.considerEnabledForNonUI?a("div",{className:e?"mt-3 -ml-2 flex flex-wrap items-center justify-center gap-2":"mt-2 flex flex-wrap items-center gap-2",children:n.considerEnabledForNonUI&&a("p",{className:"font-small text-muted",children:r?a(G,{defaultMessage:"{learnSafely} or {giveFeedback}.",id:"e90tCrG7ls",values:{learnSafely:a(I,{href:Wn,external:!0,children:a(G,{defaultMessage:"Learn how to use Cowork safely",id:"Cxr7ieOSct"})}),giveFeedback:a(I,{onClick:o,children:a(G,{defaultMessage:"give us feedback",id:"ocNaWcgW5X"})})}}):a(G,{defaultMessage:"{learnSafely}.",id:"LOH63KpAMC",values:{learnSafely:a(I,{href:Wn,external:!0,children:a(G,{defaultMessage:"Learn how to use Cowork safely",id:"Cxr7ieOSct"})})}})})}):null}function qn(){let e=Xe(),t=_("cowork_home_greeting_polish"),{isExpanded:n}=ue(),r=We(),i=je();return l("div",{className:"mb-6 pl-2",children:[e&&a(er,{className:(r?!i:n)?"opacity-0":"opacity-100"}),t?a(ln,{}):l("div",{className:"flex items-start",children:[a("div",{className:"-ml-10 mr-3 mt-1 shrink-0 hidden md:block",children:a(R,{size:28,className:"block"})}),a("h1",{className:"font-claude-response-title text-primary",children:a(G,{defaultMessage:"What can I take off your plate?",id:"mWPGSbK6BB"})})]}),a(Kn,{centered:t})]})}function Jn(){let e=zt(),{model:t,coworkEffortLevel:n}=Lt(),i=P(),a=H(e=>e.selectedProjectUuids),o=H(e=>e.selectedFolders),s=le(e=>ve(e.spaces,o)?.id),c=$t(s),l=be();return qt({promptHasContent:!e,model:t,effortLevel:n,projectUuid:i?[...a][0]:void 0,hasSpace:c,memoryMode:l,draftRoute:r(xe)}),null}function Yn(){let e=et(),t=zt();return e?l("div",{className:u("mt-3 flex items-center justify-end gap-2 text-footnote text-muted transition-opacity duration-150",t?"opacity-0":"opacity-100"),children:[a(z,{keys:"cmd+enter"}),a("span",{children:a(G,{defaultMessage:"to start a task and keep going",id:"FQcUn8+hWB"})})]}):null}function Xn({placeholder:e}){let[t]=Vt(),n=e??t;return a("div",{className:"h-52","aria-hidden":"true",children:a("div",{className:`pointer-events-none mx-2 h-[7.625rem] select-none rounded-[20px] bg-surface-3 pl-5 pt-5 md:mx-0 ${Ut}`,children:a("span",{className:"block text-muted",children:n})})})}function Zn(){}function Qn({markEditorReady:e,isCommandPaletteOpen:t,disabled:n,showVMDownloadBanner:r}){let i=an(),o=K(),{invalidEgressAllowedDomains:c}=vt(),u=_("cowork_home_greeting_polish")?o.formatMessage({defaultMessage:"Describe a task, from a quick fix to a multi-step job.",id:"tV2NkM49Bx"}):void 0,d=Kt(),f=Xt(),{mode:p}=Zt();return i?l(s,{children:[a(dn,{}),l("div",{className:"isolate",children:[a(Ht,{placement:"onpage",onReady:e,enableScreenDrop:!t&&!f,disabled:n,hideAlertBand:!0,placeholder:u}),a(it,{disabled:n}),p&&a(Wt,{placement:"onpage",onRetry:Zn}),a(Yn,{})]}),r&&a("div",{className:"mt-4",children:a(pt,{deferProgressUntilSessionPending:!0,sessionHostLoopMode:d})}),a(gt,{}),c.length>0&&a(Un,{}),""]}):a(Xn,{placeholder:u})}function $n(){let n=Gn(),r=Fe(),i=We(),o=Qe(),f=y(ee),p=Ee(),m=ot(),h=Qt(),_=N(),v=h.required&&_!==void 0,b=_==="remote"?"soft":"auto",x=v&&h.visible,S=_==="remote"?x:h.required,C=rt(),w=j(),{markEditorReady:T}=fe(),[E,te]=e(!1),ne=t(()=>{T(),te(!0)},[T]);De("chat_input_ready",E?"ready":"pending",{openId:Je.cowork});let O=mt()?.isOpen??!1,k=Oe(),{activeOrganization:A,account:re}=qe(),{setTemporaryConversationUuid:M}=Te(),P=se({setTemporaryConversationUuid:M}),ie=st({source:"task_new",readDraftPermissionMode:!0,readDraftElectedDevice:!0,readDraftMemoryMode:!0}),F=d(!1);c(()=>{let e=e=>{e.key==="Enter"&&(F.current=e.metaKey||e.ctrlKey)};return window.addEventListener("keydown",e,!0),()=>window.removeEventListener("keydown",e,!0)},[]);let I=t(async e=>{let t=H.getState();t.pendingAutoSend?.status==="staged"&&t.clearPendingAutoSend();let n=F.current;return F.current=!1,await ie({...e,skipRedirect:n})},[ie]),{showModal:L,requestNotification:R,dismiss:z}=Rn();c(()=>{Ne()},[]),Bt();let oe=!r.loading&&r.status==="unsupported",B=Gt(),V=m||oe||B!==null&&B!=="loading",ce=V||B==="loading";return In({kind:"new",enabled:n&&!!A&&w!==void 0&&!w?.needsAuth&&!V&&(!k.orgAvailable||!k.isRemote)}),A?!n||w===void 0?null:l($e,{className:"h-full !mt-0 !px-0 !max-w-none",children:[l(dt,{children:[a(Fn,{surface:"cowork",className:"draggable-none"}),a(at,{})]}),a("div",{className:"flex h-full",children:l("div",{className:"relative isolate flex h-full min-w-0 flex-1 flex-col overflow-x-clip overflow-y-auto",children:[a("div",{className:"absolute inset-0 -z-10",children:a(rn,{})}),!i&&f&&!p&&a(we,{fixed:!0,className:"!bg-transparent"}),l(ae,{surface:"cowork",willRedirectOnSubmit:!0,onCreate:P,onSessionCreate:I,offersSessionMemorySwitch:!0,coworkEffortEnabled:r.considerEnabledForNonUI,coworkExtendedThinkingEnabled:o,hostsUrlComposerSeed:!0,children:[a(At,{}),a(Ot,{}),a(hn,{}),a(sn,{disabled:m||oe||B!==null&&B!=="loading",deferred:w?.needsAuth===!0||B==="loading"}),a(Jn,{}),a(kt,{}),l("div",{className:"flex flex-1 flex-col items-center justify-start px-4 pb-6 pt-24 md:px-14",children:[l("div",{className:"w-full max-w-2xl",children:[m&&a("div",{className:"mb-4",children:a(ut,{})}),x&&a("div",{className:"mb-8",children:a(Yt,{state:h,wording:b})}),!S&&C.visible&&a("div",{className:"mb-8",children:a(lt,{state:C})}),Bn,oe&&a("div",{className:"mb-4",children:a(jt,{code:r.unsupportedCode,reason:r.localizedUnsupportedStringFromDesktop})}),a(Mt,{className:"mb-4"}),l("div",{className:u("mb-4",V&&"opacity-40 pointer-events-none"),children:[a(qn,{}),a(Qn,{markEditorReady:ne,isCommandPaletteOpen:O,disabled:ce,showVMDownloadBanner:(r.considerEnabledForNonUI??!1)&&(!k.orgAvailable||!k.isRemote)})]})]}),!V&&l(s,{children:[a(Et,{}),a(Dt,{}),!re?.settings.cowork_onboarding_completed_at&&a(Pn,{}),a(bn,{})]})]}),a(Nt,{})]})]})}),a(Hn,{isOpen:L,onClose:z,onNotifyMe:R})]}):g()?null:a(D,{to:"/no-organization"})}function er({className:e}){let{activeOrganization:t}=qe(),n=t?.name;return l("div",{className:u("ml-0.5 inline-flex items-center gap-1.5 rounded-lg h-8 pl-2 pr-2.5 mb-5 text-center font-small bg-neutral-30 text-muted select-none transition-opacity duration-150",e),children:[t?.has_icon?a(nt,{organization:t,size:"sm",className:"shadow-sm"}):a(Re,{size:20,className:"-mx-0.5"}),n]})}export{$n as AgentNewPageContent};