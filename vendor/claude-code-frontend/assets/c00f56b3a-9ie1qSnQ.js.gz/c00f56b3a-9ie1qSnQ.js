var e=[{id:"briefing",name:"Briefing",description:"Summary of your calendar, emails, and messages.",icon:"Sun",category:"communication",trigger:{kind:"schedule",defaultCron:"30 12 * * 1-5"},suggestedConnectors:["Google Calendar","Gmail","Slack"],prompt:`Generate a briefing to help me catch up. Include:

1. Schedule \u2014 List upcoming meetings and events with times, attendees, and any preparation needed
2. Important emails \u2014 Summarize unread emails that need attention, grouped by urgency
3. Messages requiring response \u2014 Flag any direct messages or mentions that need a reply
4. Action items \u2014 List any pending tasks or follow-ups from recent activity

Keep the briefing concise and scannable. If there's nothing notable in a section, skip it rather than saying "nothing to report."`},{id:"email-triage",name:"Email triage",description:"Categorize and prioritize your inbox, with draft responses for urgent items.",icon:"Mailbox",category:"communication",trigger:{kind:"schedule",defaultCron:"0 15 * * 1-5"},suggestedConnectors:["Gmail"],prompt:`Review my inbox for new and unread emails. For each email:

1. Categorize into: Urgent, Action Needed, FYI, or Low Priority
2. Summarize the key point in one sentence
3. Draft a response for any emails marked Urgent or Action Needed

Present results grouped by category, with Urgent items first. For drafted responses, keep the tone professional and concise. If the inbox is empty or all caught up, confirm that briefly.`},{id:"system-health-check",name:"System health check",description:"Monitor infrastructure and services for errors, outages, and performance issues.",icon:"Activity",category:"monitoring",trigger:{kind:"schedule",defaultCron:"0 12 * * *"},suggestedConnectors:["PagerDuty","Datadog","Sentry"],prompt:`Perform a health check across connected monitoring services. Report:

1. Active incidents \u2014 Any ongoing outages or incidents with severity and status
2. Errors and warnings \u2014 New errors or warning patterns since the last check
3. Performance anomalies \u2014 Unusual latency, error rates, or resource usage
4. Resolved items \u2014 Incidents or alerts that were resolved since the last check

Prioritize by severity. For each issue, include the service affected and a direct link if available. If all systems are healthy, confirm with a brief "All systems nominal" message.`},{id:"issue-triage",name:"Issue triage",description:"Review and categorize incoming issues, bugs, and feature requests.",icon:"Tasks",category:"productivity",trigger:{kind:"schedule",defaultCron:"30 15 * * 1-5"},suggestedConnectors:["Linear"],prompt:`Review new and unassigned issues across connected project trackers. For each issue:

1. Categorize as: Bug, Feature Request, Improvement, or Question
2. Assess priority based on content: Critical, High, Medium, or Low
3. Suggest assignment if the issue clearly relates to a specific team or area
4. Flag duplicates if similar issues already exist

Present a summary table of all triaged issues, then detailed notes for Critical and High priority items. If there are no new issues, confirm briefly.`},{id:"pr-review-digest",name:"PR review digest",description:"Overview of open PRs, review status, and what needs attention.",icon:"GitPullRequest",category:"monitoring",trigger:{kind:"schedule",defaultCron:"0 18 * * 1-5"},prompt:`Review all open pull requests across the connected repositories. For each PR, report:

1. Title and author
2. How long it's been open
3. Review status \u2014 approved, changes requested, or awaiting review
4. CI status \u2014 passing, failing, or pending
5. Merge conflicts \u2014 whether the branch is up to date

Highlight any PRs that have been open for more than 3 days or have failing checks. Sort by oldest first. If there are no open PRs, confirm briefly.`},{id:"dependency-update-check",name:"Dependency update check",description:"Scan for outdated packages, security patches, and breaking changes.",icon:"ShieldSearch",category:"monitoring",trigger:{kind:"schedule",defaultCron:"30 18 * * 1"},prompt:`Check all dependencies in the connected repositories for available updates. For each outdated dependency:

1. Current version vs latest version
2. Update type \u2014 major, minor, or patch
3. Breaking changes noted in changelogs
4. Security advisories \u2014 any known CVEs or vulnerabilities

Prioritize security-related updates. Group results by repository and severity. If everything is up to date, confirm briefly.`},{id:"release-notes-drafter",name:"Release notes drafter",description:"Draft user-facing release notes each time a PR merges to the main branch.",icon:"Scroll",category:"reporting",trigger:{kind:"github",events:["pull_request.closed"]},prompt:`A pull request was just merged to the main branch. Draft a release-notes entry for it.

1. Read the PR title, description, and diff. Identify the user-visible change \u2014 a new feature, a bug fix, a breaking change, or an internal-only refactor.
2. If the change is internal-only (tests, CI, build tooling, comments, dead-code removal, pure refactors), stop and post a comment saying "Internal change \u2014 no release note." Do not draft an entry for these.
3. Otherwise, draft a one-paragraph entry written for end users, not contributors. Use the imperative voice. Avoid jargon and internal codenames. Do not mention file paths, function names, or commit SHAs.
4. Classify the entry under one of: New, Improved, Fixed, or Breaking.
5. If this is a breaking change, explicitly list what users need to do to migrate.
6. Post the draft as a PR comment. Include a one-line "suggested changelog location" hint if the repo has an obvious CHANGELOG.md or docs/changelog path.

Keep drafts short \u2014 2 to 4 sentences. Long release notes don't get read.`},{id:"flaky-test-tracker",name:"Flaky test tracker",description:"Find tests that pass and fail intermittently across recent CI runs.",icon:"Beaker",category:"monitoring",trigger:{kind:"schedule",defaultCron:"0 16 * * 1"},prompt:`Identify flaky tests \u2014 tests that both passed and failed on the same code over the past week.

1. Pull CI workflow runs from the last 7 days on the default branch. Focus on test jobs.
2. For each test failure, note the test name, file, and the commit it ran against. A test is flaky if it failed on a commit where the same test also passed (in a retry, a re-run, or a later run on the same SHA).
3. Rank flaky tests by flake rate (failures \u00F7 total runs) and total time wasted on retries.
4. For the top 5, include: test name and file path, flake rate, a link to one failing and one passing run on the same commit, and the failure message pattern if it's consistent.
5. Note any tests that are newly flaky this week vs. ones that appeared in last week's report.
6. For the #1 flakiest test, attempt a fix: read the test and the code it exercises, identify the likely cause (race condition, unawaited promise, time/order dependence, shared state, network reliance), apply a targeted fix, verify it passes locally across several runs, and open a pull request titled "fix(flaky): <test name>" with the root-cause analysis in the description. If you can't determine a safe fix, open a draft PR that quarantines the test (skip with a comment linking this report) instead.

Present as a ranked table followed by per-test detail, then a link to the fix PR. If no flaky tests are found, confirm that briefly along with the total number of test runs scanned.`}];function t(t){return e.find(e=>e.id===t)}var n="ccr-routine-draft:";function r(e){return`${n}${e}`}function i(e,t){try{for(let e of Object.keys(sessionStorage))e.startsWith(n)&&sessionStorage.removeItem(e);sessionStorage.setItem(r(e),JSON.stringify(t))}catch{}}function a(e){try{let t=sessionStorage.getItem(r(e));if(!t)return null;let n=JSON.parse(t);if(typeof n.prompt!="string"||!n.prompt)return null;let i=Array.isArray(n.githubEvents)?n.githubEvents.filter(e=>typeof e=="string"):[];return{name:typeof n.name=="string"?n.name:"",prompt:n.prompt,cronExpression:typeof n.cronExpression=="string"?n.cronExpression:null,githubEvents:i.length>0?i:null}}catch{return null}}export{t as i,i as n,e as r,a as t};