import{Ba as e,Da as t,La as n,Sa as r,aa as i,ia as a,ja as o,oa as s,ra as c,za as l}from"./vendor-frame-CvMkXlR3.js";import{Zt as u}from"./shared-common-0-BGMEEQm3.js";import{a as d,h as f,i as p,r as m}from"./vendor-motion-CZ1BlEHl.js";import{o as h,s as g}from"./c2fdd8942-CuTW3Qy-.js";import{Fa as ee,Vi as te,lo as ne,oa as re}from"./shared-frame-DdWfvW_D.js";import{l as _,p as ie}from"./vendor-intl-KLfag9z3.js";import{L as ae}from"./shared-11-BNKeel3T.js";import{Ja as oe,Oo as v,Qa as se,Xa as ce,Ya as le,jo as y,ko as ue,no as de}from"./shared-1-BRnjJFd5.js";var fe="__cwhr_draft",pe=1e3,b=String.raw`
(function () {
  "use strict";
  if (window.__coworkHtmlReviewGuest) return;
  window.__coworkHtmlReviewGuest = true;

  var READY_TYPE = "__cowork_html_review_ready__";
  var SEL_CLASS = "__cwhr-sel";
  var CONTEXT_LEN = 32;
  var EXACT_CAP = 1000;
  var port = null;
  var mode = false;
  var pins = [];
  var quotes = [];
  // Resolved Range per quote id; invalidated on DOM mutation and on a
  // fresh quotes set. Scroll/resize re-reports just re-read
  // getClientRects() from the cached Range. Null prototype - ids are
  // collaborator-writable and must not collide with Object.prototype.
  var quoteRanges = Object.create(null);
  var hoverEl = null;
  var selected = null;
  var hasTextSel = false;
  var rafPending = false;
  // Capture before page body scripts can shadow them; start() defers
  // to DOMContentLoaded which page code can race.
  var _MessageChannel = window.MessageChannel;
  var _topPost = window.top.postMessage.bind(window.top);

  function visibleText(el) {
    // innerText drops display:none/visibility:hidden subtrees; keep an
    // empty innerText (icon-only el) rather than falling through to
    // textContent which would re-include hidden text.
    var t = typeof el.innerText === "string" ? el.innerText : (el.textContent || "");
    return t.replace(/\s+/g, " ").trim();
  }

  // Comment-mode cursor: the comment bubble itself (a 24px white teardrop,
  // tail tip bottom-left = the hotspot), drawn by the browser so it has no
  // lag; the host paints only the inspector box and, on click, the pin.
  // Same glyph as the host's pins (size-6 rounded-full rounded-bl-[2px]);
  // cursor images take no CSS shadow, so a slightly stronger 1px ring
  // stands in for ring + shadow. SVG first (rasterised at device scale
  // where supported), the same glyph as a 24px PNG for engines without
  // SVG cursors (WebKit), then the arrow.
  var BUBBLE_SVG =
    "<svg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24'>" +
    "<path d='M12 .5h0A11.5 11.5 0 0 1 23.5 12v0A11.5 11.5 0 0 1 12 23.5H2.5a2 2 0 0 1-2-2V12A11.5 11.5 0 0 1 12 .5Z' fill='#fff' stroke='rgba(0,0,0,0.22)' stroke-width='1'/>" +
    "</svg>";
  var BUBBLE_PNG =
    "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAACjklEQVR4AbRWS2gaURR9TGpiFTUEWpKQkA+EruqizWcRSBRT/G8KKpXiyo0ra1fVNiDFLmypFUo3iht/iO4Uay1FGwtFECl1p6KWLly4CGqrSMTY+wRFQ7WhGYd7Zu697845b+7M8B6BJh+UxcXFG3a7XeTxeHQAC+C12+1+ZLPZhHgMbp8FjLWxAkaj8U48Hg8lEomfIpEoLBaLLTKZTAd4LJFI3kD8HsZ+xGKxoMFgYI9T+JvAtUAg8FylUn3hcDj8ra0t6vLyMmKxWIhCofSAfZyDMRqXy+Wr1eqvPp/vKYjMAEZsRMDpdN6MRCKf+Xz+8cbGBm2kckIAtXShUGgKh8Mnfr9/Ybh0IKDT6a4vLS19EggE+wwGY7jmUj6TyUTQyv35+fmP0MbBexkISKVS+97e3u1LsU0oAo67Go3G1i/pCZjN5t3Nzc0H/zPzPlH/ip8EWvbQYrHs4hwWmN3e3n62traGfZy7MtbX12fYbPYTIKIQOzs7C6urq/cgINVWVlaO4EtjEXq9nken06mksgMZtJthtVp5xNzcHBsEIEWu0Wg0RKVS2USz2WTigFx6hPCkMTfRarXgB6WQzd/j63Q6bdK+nB7j0KnRaCCCIMpTE4D2oEql8m1qAvV6/VSr1U5PIJvN+qFjv6fyBIVC4ZfD4XgJAmekC9RqNZROp1+FQqESCCDSBWCVO1EoFC8wOQZpAnjm0Wj0O/xX94H4HNAzotvtNnreFU6lUgllMplAMpnclcvlp8NURC6Xi8BLGc5N9NvtNqpWq6hcLqN8Pn8OLUkAMe/g4EAOG4WzizcTJpPpA6zFIpfL9Ra2I45/IRgM2lKp1LtisXjs9XpvHR4eHimVythF4n78BwAA//8r8OPFAAAABklEQVQDAPCY8Oae0TJxAAAAAElFTkSuQmCC";
  var BUBBLE_CURSOR =
    "url(\"data:image/svg+xml," + encodeURIComponent(BUBBLE_SVG) + "\") 1 23, " +
    "url(\"" + BUBBLE_PNG + "\") 1 23, default";

  function injectStyle() {
    var style = document.createElement("style");
    // Hover box is painted by the host (from streamed rects); the guest
    // marks the selected element and, in comment mode, swaps the native
    // cursor for the comment bubble (forced, so page cursor styles don't
    // fight the picker). While a composer or thread card is open the arrow
    // returns, so the bubble cursor and the pin just placed never show at
    // once. Keyed on <html> data attributes, which page scripts that
    // rewrite body.className leave alone; ":not(#_)" lifts the rules to
    // id-level specificity so a page's own !important cursor rules lose.
    var ANY = ":not(#__cwhr_)";
    var MODE = "html[data-cwhr-mode]";
    var COMPOSING = MODE + "[data-cwhr-composing]";
    style.textContent =
      "." + SEL_CLASS + "{outline:1px solid hsl(40 70% 40%) !important;outline-offset:0;}" +
      MODE + ANY + "," + MODE + " " + ANY + "{cursor:" + BUBBLE_CURSOR + " !important;}" +
      COMPOSING + ANY + "," + COMPOSING + " " + ANY + "{cursor:default !important;}";
    (document.head || document.documentElement).appendChild(style);
  }

  function isUnique(sel) {
    try {
      return document.querySelectorAll(sel).length === 1;
    } catch (e) {
      return false;
    }
  }

  // Mirrors the host's stripInvisibles ranges. The host strips these
  // from stored selectors, so a selector built on a value containing
  // them would validate here but never match again - skip those rungs
  // and fall through to the structural ladder instead.
  function hasInvisibles(s) {
    for (var i = 0; i < s.length; i++) {
      var c = s.codePointAt(i);
      if (c > 0xffff) i++;
      if (
        c <= 0x1f ||
        c === 0x061c ||
        c === 0x070f ||
        c === 0xad ||
        (c >= 0x7f && c <= 0x9f) ||
        c === 0x115f ||
        c === 0x1160 ||
        c === 0x180e ||
        (c >= 0x200b && c <= 0x200f) ||
        (c >= 0x202a && c <= 0x202e) ||
        (c >= 0x2060 && c <= 0x2064) ||
        (c >= 0x2066 && c <= 0x2069) ||
        c === 0x3164 ||
        c === 0xfeff ||
        (c >= 0xfff9 && c <= 0xfffb) ||
        c === 0xffa0 ||
        (c >= 0xe0000 && c <= 0xe007f)
      ) {
        return true;
      }
    }
    return false;
  }

  function escapeAttr(v) {
    return String(v).replace(/\\/g, "\\\\").replace(/"/g, '\\"');
  }

  // Selector ladder: unique #id -> unique [data-*] -> structural
  // tag:nth-of-type path rooted at the nearest unique-id ancestor.
  function selectorFor(el) {
    if (el.id && !hasInvisibles(el.id) && isUnique("#" + CSS.escape(el.id))) {
      return "#" + CSS.escape(el.id);
    }
    for (var i = 0; i < el.attributes.length; i++) {
      var attr = el.attributes[i];
      if (
        attr.name.indexOf("data-") === 0 &&
        attr.value &&
        !hasInvisibles(attr.value)
      ) {
        var dataSel = "[" + attr.name + '="' + escapeAttr(attr.value) + '"]';
        if (isUnique(dataSel)) return dataSel;
      }
    }
    var parts = [];
    var cur = el;
    while (cur && cur !== document.body && cur.nodeType === 1 && parts.length < 10) {
      var sel = cur.tagName.toLowerCase();
      var parent = cur.parentElement;
      if (parent) {
        var sameTag = [];
        for (var c = 0; c < parent.children.length; c++) {
          if (parent.children[c].tagName === cur.tagName) sameTag.push(parent.children[c]);
        }
        if (sameTag.length > 1) {
          sel += ":nth-of-type(" + (sameTag.indexOf(cur) + 1) + ")";
        }
      }
      parts.unshift(sel);
      if (
        parent &&
        parent.id &&
        !hasInvisibles(parent.id) &&
        isUnique("#" + CSS.escape(parent.id))
      ) {
        parts.unshift("#" + CSS.escape(parent.id));
        return parts.join(" > ");
      }
      cur = parent;
    }
    if (cur === document.body) {
      parts.unshift("body");
      return parts.join(" > ");
    }
    // Depth cap hit without a root - an unrooted chain would match the
    // first structural pattern anywhere in the document. Mark the pin
    // detached instead of attaching it to the wrong element.
    return ":not(*)";
  }

  function descriptorFor(el) {
    var tag = "<" + el.tagName.toLowerCase() + ">";
    var idPart = el.id ? " #" + el.id : "";
    var text = visibleText(el).slice(0, 60);
    var textPart = text ? ' "' + text + '"' : "";
    // Nearest id'd ancestor, skipping the UCR-injected
    // #artifacts-component-root-* wrapper which is implementation noise.
    var section = el.parentElement;
    while (
      section &&
      (!section.id || section.id.indexOf("artifacts-component-root") === 0)
    ) {
      section = section.parentElement;
    }
    var sectionPart = section && section.id ? " in #" + section.id : "";
    return (tag + idPart + textPart + sectionPart).slice(0, 400);
  }

  // textContent offset of (node, offset) within body - the coordinate
  // system text-quote anchors are stored in. -1 when the boundary
  // isn't under body (shadow root, detached).
  function textOffset(node, offset) {
    var body = document.body;
    if (!body) return -1;
    try {
      var pre = document.createRange();
      pre.selectNodeContents(body);
      pre.setEnd(node, offset);
      return pre.toString().length;
    } catch (e) {
      return -1;
    }
  }

  // Inverse: build a Range covering [start, end) in body.textContent.
  function rangeForOffsets(start, end) {
    var body = document.body;
    if (!body) return null;
    var walker = document.createTreeWalker(body, NodeFilter.SHOW_TEXT);
    var acc = 0;
    var range = document.createRange();
    var haveStart = false;
    var t;
    while ((t = walker.nextNode())) {
      var next = acc + t.length;
      if (!haveStart && start < next) {
        range.setStart(t, start - acc);
        haveStart = true;
      }
      if (haveStart && end <= next) {
        range.setEnd(t, end - acc);
        return range;
      }
      acc = next;
    }
    return null;
  }

  // Context-scored search (W3C text-quote resolution): slice-check the
  // hint, else pick the occurrence whose surrounding chars best match
  // prefix/suffix. MIRRORS locateTextQuote() above line-for-line - the
  // tested export is the contract; this copy is what the sandbox runs.
  function locateQuote(text, q) {
    var ex = q.exact;
    if (!ex) return null;
    var hint = q.startOffset >= 0 ? q.startOffset : 0;
    if (text.slice(hint, hint + ex.length) === ex) {
      return { start: hint, end: hint + ex.length };
    }
    var best = -1;
    var bestScore = -1;
    var bestDist = Infinity;
    var scanned = 0;
    for (var idx = text.indexOf(ex); idx !== -1 && ++scanned <= 1000; idx = text.indexOf(ex, idx + 1)) {
      var before = text.slice(Math.max(0, idx - CONTEXT_LEN), idx);
      var after = text.slice(idx + ex.length, idx + ex.length + CONTEXT_LEN);
      var sc = 0;
      for (var i = 1; i <= q.prefix.length && i <= before.length; i++) {
        if (q.prefix[q.prefix.length - i] !== before[before.length - i]) break;
        sc++;
      }
      for (var j = 0; j < q.suffix.length && j < after.length; j++) {
        if (q.suffix[j] !== after[j]) break;
        sc++;
      }
      var dist = Math.abs(idx - hint);
      if (sc > bestScore || (sc === bestScore && dist < bestDist)) {
        best = idx;
        bestScore = sc;
        bestDist = dist;
      }
    }
    return best === -1 ? null : { start: best, end: best + ex.length };
  }

  function collectLineRects(range, cap) {
    var out = [];
    var rects = range.getClientRects();
    for (var i = 0; i < rects.length && out.length < cap; i++) {
      var r = rects[i];
      if (r.width > 0 && r.height > 0) {
        out.push({ x: r.left, y: r.top, w: r.width, h: r.height });
      }
    }
    return out;
  }

  function reportTextSel(full) {
    if (!port) return;
    var sel = window.getSelection();
    var r = sel && !sel.isCollapsed && sel.rangeCount > 0 ? sel.getRangeAt(0) : null;
    if (!r || !document.body || !document.body.contains(r.commonAncestorContainer)) {
      if (hasTextSel) {
        hasTextSel = false;
        port.postMessage({ type: "textClear" });
      }
      return;
    }
    hasTextSel = true;
    var br = r.getBoundingClientRect();
    var msg = {
      type: "textCapture",
      rect: { x: br.left, y: br.top, w: br.width, h: br.height },
      lineRects: collectLineRects(r, 80),
    };
    if (full) {
      var live = document.body.textContent || "";
      var so = textOffset(r.startContainer, r.startOffset);
      var eo = textOffset(r.endContainer, r.endOffset);
      if (so < 0 || eo < 0 || eo <= so) {
        // Unanchorable selection (shadow root, foreign node). A
        // rect-only post here would make the host pair the new rect
        // with a stale prior anchor - clear instead.
        hasTextSel = false;
        port.postMessage({ type: "textClear" });
        return;
      }
      // Denomination invariant: exact/prefix/suffix are byte-identical
      // slices of body.textContent. Truncation adjusts endOffset so
      // the host's (endOffset - startOffset === exact.length) shape
      // check holds. Cut points back off surrogate halves - a lone
      // surrogate would never relocate and fails UTF-8 persist.
      var capped = Math.min(eo, so + EXACT_CAP);
      if (capped < eo) {
        var hc = live.charCodeAt(capped - 1);
        if (hc >= 0xd800 && hc <= 0xdbff) capped--;
      }
      if (capped <= so) {
        port.postMessage(msg);
        return;
      }
      var pStart = Math.max(0, so - CONTEXT_LEN);
      var pc = live.charCodeAt(pStart);
      if (pc >= 0xdc00 && pc <= 0xdfff) pStart++;
      var sEnd = Math.min(live.length, capped + CONTEXT_LEN);
      if (sEnd < live.length) {
        var sc = live.charCodeAt(sEnd - 1);
        if (sc >= 0xd800 && sc <= 0xdbff) sEnd--;
      }
      msg.exact = live.slice(so, capped);
      msg.prefix = live.slice(pStart, so);
      msg.suffix = live.slice(capped, sEnd);
      msg.startOffset = so;
      msg.endOffset = capped;
    }
    port.postMessage(msg);
  }

  function clearSelection() {
    if (selected) {
      selected.classList.remove(SEL_CLASS);
      selected = null;
    }
  }

  // rAF-throttled cursor + hover-rect stream so the host can paint the
  // inspector hover box (and knows the pointer is present) in comment mode.
  var cursorPending = false;
  var cursorX = -1;
  var cursorY = -1;
  function flushCursor() {
    cursorPending = false;
    if (!port) return;
    var hover = null;
    if (
      hoverEl &&
      hoverEl.nodeType === 1 &&
      hoverEl !== document.body &&
      hoverEl !== document.documentElement
    ) {
      var r = hoverEl.getBoundingClientRect();
      if (r.width > 0 || r.height > 0) {
        hover = { x: r.left, y: r.top, w: r.width, h: r.height };
      }
    }
    port.postMessage({ type: "cursor", x: cursorX, y: cursorY, hover: hover });
  }
  function scheduleCursor() {
    if (!cursorPending) {
      cursorPending = true;
      requestAnimationFrame(flushCursor);
    }
  }
  function onMouseMove(ev) {
    if (!mode || !port) return;
    // Over the scrollbar gutter (clientX/Y past the content box) - hide
    // the hover box like a leave.
    var de = document.documentElement;
    if (ev.clientX >= de.clientWidth || ev.clientY >= de.clientHeight) {
      cursorX = -1;
      cursorY = -1;
      hoverEl = null;
      scheduleCursor();
      return;
    }
    cursorX = ev.clientX;
    cursorY = ev.clientY;
    hoverEl = ev.target;
    scheduleCursor();
  }
  function onMouseLeave() {
    if (!mode || !port) return;
    cursorX = -1;
    cursorY = -1;
    hoverEl = null;
    scheduleCursor();
  }

  function onClick(ev) {
    if (!port) return;
    if (!mode) {
      // Mode off: don't intercept the page, just let the host close any
      // open popover (thread card click-away). A non-collapsed selection
      // means the click ended a drag-select - not a click-away.
      var s = window.getSelection();
      if (!s || s.isCollapsed) port.postMessage({ type: "clickAway" });
      return;
    }
    ev.preventDefault();
    ev.stopImmediatePropagation();
    var el = ev.target;
    if (!el || el.nodeType !== 1 || el === document.documentElement) return;
    if (el === document.body && el.firstElementChild) {
      // Pin on body is rarely intentional; keep it anyway but as body.
    }
    clearSelection();
    selected = el;
    el.classList.add(SEL_CLASS);
    var rect = el.getBoundingClientRect();
    var pinX = rect.width > 0 ? (ev.clientX - rect.left) / rect.width : 0.5;
    var pinY = rect.height > 0 ? (ev.clientY - rect.top) / rect.height : 0.5;
    port.postMessage({
      type: "capture",
      selector: selectorFor(el).slice(0, 1000),
      textHint: visibleText(el).slice(0, 300),
      descriptor: descriptorFor(el),
      pinX: Math.min(1, Math.max(0, pinX)),
      pinY: Math.min(1, Math.max(0, pinY)),
      clientX: ev.clientX,
      clientY: ev.clientY,
      rectLeft: rect.left,
      rectTop: rect.top,
    });
  }

  function reportRects() {
    rafPending = false;
    if (!port) return;
    // Selected element's live bounds - keeps the host's draft pin /
    // inspector tag / composer glued through scroll and reflow.
    if (selected) {
      var sr = selected.getBoundingClientRect();
      port.postMessage({
        type: "selRect",
        left: sr.left,
        top: sr.top,
        w: sr.width,
        h: sr.height,
        found:
          (sr.width > 0 || sr.height > 0) &&
          document.documentElement.contains(selected),
      });
    }
    var rects = [];
    for (var i = 0; i < pins.length; i++) {
      var p = pins[i];
      var el = null;
      try {
        el = document.querySelector(p.selector);
      } catch (e) {
        el = null;
      }
      if (!el) {
        rects.push({ id: p.id, x: 0, y: 0, found: false });
        continue;
      }
      var r = el.getBoundingClientRect();
      if (r.width === 0 && r.height === 0) {
        rects.push({ id: p.id, x: 0, y: 0, found: false });
        continue;
      }
      rects.push({
        id: p.id,
        x: r.left + p.pinX * r.width,
        y: r.top + p.pinY * r.height,
        found: true,
      });
    }
    var quoteRects = [];
    if (quotes.length > 0) {
      var live = null;
      for (var qi = 0; qi < quotes.length; qi++) {
        var q = quotes[qi];
        var qr = quoteRanges[q.id];
        if (qr === undefined) {
          if (live === null) {
            live = (document.body && document.body.textContent) || "";
          }
          var loc = locateQuote(live, q);
          qr = (loc && rangeForOffsets(loc.start, loc.end)) || null;
          quoteRanges[q.id] = qr;
        }
        // Zero paintable rects (display:none subtree) reports as
        // not-found so the host docks it as detached instead of
        // rendering nothing clickable.
        var qlr = qr ? collectLineRects(qr, 80) : [];
        quoteRects.push(
          qlr.length > 0
            ? { id: q.id, found: true, lineRects: qlr }
            : { id: q.id, found: false, lineRects: [] }
        );
      }
    }
    port.postMessage({
      type: "rects",
      rects: rects,
      quoteRects: quoteRects,
      scrollY: window.scrollY || 0,
    });
  }

  function scheduleRects() {
    if (rafPending) return;
    rafPending = true;
    var done = false;
    function run() {
      if (done) return;
      done = true;
      reportRects();
    }
    // rAF for paint alignment, with a timeout fallback - rAF is
    // suspended entirely in hidden tabs and pins must still settle
    // when the tab becomes visible after background loading.
    requestAnimationFrame(run);
    setTimeout(run, 150);
  }

  function setMode(on) {
    mode = !!on;
    document.documentElement.toggleAttribute("data-cwhr-mode", mode);
    if (!mode) {
      hoverEl = null;
      clearSelection();
    }
  }

  function setComposing(open) {
    document.documentElement.toggleAttribute("data-cwhr-composing", !!open);
  }

  function onPortMessage(ev) {
    var data = ev.data;
    if (!data) return;
    if (data.type === "mode") setMode(data.on);
    else if (data.type === "composing") setComposing(data.open);
    else if (data.type === "pins") {
      pins = Array.isArray(data.pins) ? data.pins : [];
      scheduleRects();
    } else if (data.type === "quotes") {
      quotes = Array.isArray(data.quotes) ? data.quotes : [];
      quoteRanges = Object.create(null);
      scheduleRects();
    } else if (data.type === "clearSelection") {
      clearSelection();
    } else if (data.type === "clearTextSel") {
      var ts = window.getSelection();
      if (ts) ts.removeAllRanges();
      hasTextSel = false;
    } else if (data.type === "restoreScroll") {
      var ry = Number(data.y);
      if (isFinite(ry) && ry > 0) {
        // Apply now and again at load - late images/fonts can grow the
        // document after the first attempt clamps short.
        window.scrollTo(0, ry);
        window.addEventListener("load", function () {
          window.scrollTo(0, ry);
        });
      }
    }
  }

  function start() {
    injectStyle();
    var channel = new _MessageChannel();
    port = channel.port1;
    port.onmessage = onPortMessage;
    // Sandboxed srcdoc origins can be opaque; "*" is required. The
    // payload carries only the mount token (multiple sandboxes can be
    // mounted at once - the token routes the port to the right overlay)
    // and the channel port itself is pairwise-secure.
    _topPost(
      { type: READY_TYPE, token: "__CWHR_TOKEN__" },
      "*",
      [channel.port2]
    );
    document.addEventListener("mousemove", onMouseMove, true);
    // documentElement (not document, capture) so this fires only when the
    // pointer leaves the viewport - capture-phase on document would fire for
    // every intra-document element-boundary crossing.
    document.documentElement.addEventListener("mouseleave", onMouseLeave);
    document.addEventListener("click", onClick, true);
    // Text-selection capture: commit on mouseup/keyup (Shift+Arrow),
    // clear on collapse. Not mode-gated; highlight-to-comment is
    // always on.
    function onSelCommit() { reportTextSel(true); }
    document.addEventListener("mouseup", onSelCommit, true);
    document.addEventListener("keyup", onSelCommit, true);
    document.addEventListener("selectionchange", function () {
      var s = window.getSelection();
      if (hasTextSel && (!s || s.isCollapsed)) reportTextSel(false);
    });
    document.addEventListener("keydown", function (ev) {
      if (ev.key === "Escape" && port) port.postMessage({ type: "dismiss" });
    }, true);
    // Scroll/resize move the hovered element under a stationary pointer -
    // re-report its rect so the host's inspector box tracks it. Mutations
    // stay rects-only (animating pages would chatter the cursor stream).
    var textSelPending = false;
    function scheduleTextSel() {
      if (textSelPending) return;
      textSelPending = true;
      requestAnimationFrame(function () {
        textSelPending = false;
        reportTextSel(false);
      });
    }
    function onLayoutChange() {
      scheduleRects();
      if (mode && hoverEl) scheduleCursor();
      if (hasTextSel) scheduleTextSel();
    }
    window.addEventListener("scroll", onLayoutChange, true);
    window.addEventListener("resize", onLayoutChange);
    // Full-cache invalidate per childList mutation is acceptable: CSS
    // animation doesn't fire the observer; JS writers at frame rate
    // would re-relocate every frame but are rare. characterData isn't
    // observed, so .data= edits leave highlights stale until the next
    // childList mutation.
    var observer = new MutationObserver(function () {
      quoteRanges = Object.create(null);
      scheduleRects();
      if (hasTextSel) scheduleTextSel();
    });
    function observe() {
      if (document.body) observer.observe(document.body, { childList: true, subtree: true });
    }
    if (document.body) observe();
    else document.addEventListener("DOMContentLoaded", observe);
    // Settle pins after late layout (fonts, images).
    setInterval(scheduleRects, 2000);
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", start);
  } else {
    start();
  }
})();
`;function me(e,t){let n=t.replace(/[^a-zA-Z0-9-]/g,""),r=`<script>${b.replace("__CWHR_TOKEN__",n)}<\/script>`,i=e=>" ".repeat(e.length),a=e.replace(/<!--[\s\S]*?-->/g,i).replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi,i).replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,i).replace(/<(?:script|style)\b[^>]*>[\s\S]*$/i,i),o=/<head(?:\s[^>]*)?>/i.exec(a);if(o){let t=o.index+o[0].length;return e.slice(0,t)+r+e.slice(t)}let s=/<html(?:\s[^>]*)?>/i.exec(a);if(s){let t=s.index+s[0].length;return e.slice(0,t)+r+e.slice(t)}let c=/^\s*<!doctype[^>]*>/i.exec(a);if(c){let t=c.index+c[0].length;return e.slice(0,t)+r+e.slice(t)}return r+e}var x=24,he="#D97757",ge="#C6613F",_e="rgba(0,0,0,0.12)",ve="0 1px 3px rgba(0,0,0,0.10), 0 4px 10px rgba(0,0,0,0.08)",ye="0 0 0 0.5px rgba(0,0,0,0.06), 0 4px 12px rgba(0,0,0,0.06), 0 16px 40px rgba(0,0,0,0.08)",be={initial:{opacity:0,y:6,scale:.98},animate:{opacity:1,y:0,scale:1},transition:{duration:.16,ease:[.2,.7,.3,1]}},xe="rgba(253, 186, 116, 0.35)",Se="rgba(253, 186, 116, 0.55)",S=80,Ce=200,we=256,Te=84,Ee=120,De=168,C=6;function Oe(e){let t=w(e.x+C,C,Math.max(C,e.boundsW-we-C)),n=e.y+C;return{left:t,top:n+e.estH<=e.boundsH-C?n:w(e.y-x-C-e.estH,C,Math.max(C,e.boundsH-e.estH-C))}}function w(e,t,n){return Math.min(n,Math.max(t,e))}function ke(e,t){let n=Number(e?.x)||0,r=Number(e?.y)||0,i=w(n,0,t.w),a=w(r,0,t.h),o=w(n+(Number(e?.w)||0),0,t.w),s=w(r+(Number(e?.h)||0),0,t.h);return o>i&&s>a?{x:i,y:a,w:o-i,h:s-a}:null}function Ae(e,t){if(!Array.isArray(e))return[];let n=[];for(let r of e.slice(0,S)){let e=ke(r,t);e&&n.push(e)}return n}function je(e,t){return typeof e=="string"?ue(e).slice(0,t):""}function Me(e){return e.toUpperCase().toLowerCase().replace(/\u03C2/g,"\u03C3").replace(/\s+/g,"")}function T(e){let t=new DOMParser().parseFromString(e,"text/html");for(let e of t.querySelectorAll("script, style, noscript, template, [hidden], dialog:not([open]), details:not([open]) > :not(summary)"))e.remove();for(let e of t.querySelectorAll("[style]")){let t=e.getAttribute("style")??"";(e.style.display.toLowerCase()==="none"||/^(?:hidden|collapse)$/.test(e.style.visibility.toLowerCase())||e.style.getPropertyValue("content-visibility").toLowerCase()==="hidden"||/(?:^|;)\s*display\s*:\s*none\b/i.test(t)||/(?:^|;)\s*(?:content-)?visibility\s*:\s*(?:hidden|collapse)\b/i.test(t))&&e.remove()}let n=t.createTreeWalker(t.body??t,NodeFilter.SHOW_TEXT),r="";for(;n.nextNode();)r+=(n.currentNode.textContent??"")+" ";return v(r,2e6)}var E=String.raw`#(?:[-\w\u0080-\uFFFF]|\\[0-9a-fA-F]{1,6} |\\[^0-9a-fA-F])+`,Ne=String.raw`\[data-[a-zA-Z0-9_.:-]+="(?:[^"\\]|\\.)*"\]`,D=String.raw`[a-z][a-z0-9-]*(?::nth-of-type\(\d{1,6}\))?`,Pe=RegExp(`^(?:${E}|${Ne}|:not\\(\\*\\)|(?:(?:${E}|body) > )?${D}(?: > ${D}){0,9})$`),O=/"(?:[^"\\]|\\.){81,}"/,Fe=/"[^"]*\s[^"]*"/,Ie=new RegExp(String.raw`#(?:[-\w\u0080-\uFFFF]|\\[0-9a-fA-F]{1,6} |\\[^0-9a-fA-F]){65,}`),k=/(?:^|> )[a-z][a-z0-9-]{32,}/,Le=/\[data-[a-zA-Z0-9_.:-]{33,}=/,Re=new RegExp(String.raw`^#(?:[-\w\u0080-\uFFFF]|\\[0-9a-fA-F]{1,6} |\\[^0-9a-fA-F]){33,} > `),ze=20,Be=new Set("a abbr address area article aside audio b base bdi bdo blockquote body br button canvas caption cite code col colgroup data datalist dd del details dfn dialog div dl dt em embed fieldset figcaption figure footer form h1 h2 h3 h4 h5 h6 head header hgroup hr html i iframe img input ins kbd label legend li link main map mark menu meta meter nav noscript object ol optgroup option output p picture pre progress q rp rt ruby s samp script search section select slot small source span strong style sub summary sup table tbody td template textarea tfoot th thead time title tr track u ul var video wbr svg math g path rect circle line text tspan polyline polygon ellipse defs use symbol image foreignobject".split(" ")),Ve=/^#artifacts-component-root-(?:html|react|svg|pdf)(?: > |$)/;function He(e){let t=globalThis.CSS?.escape;if(t)return t(e);let n="";for(let t=0;t<e.length;t++){let r=e.charCodeAt(t);r===0?n+="\uFFFD":r>=1&&r<=31||r===127||t===0&&r>=48&&r<=57||t===1&&r>=48&&r<=57&&e.charCodeAt(0)===45?n+=`\\${r.toString(16)} `:t===0&&e.length===1&&r===45?n+="\\-":n+=r>=128||r===45||r===95||r>=48&&r<=57||r>=65&&r<=90||r>=97&&r<=122?e[t]:`\\${e[t]}`}return n}function Ue(e){return O.test(e)||Fe.test(e)||Ie.test(e)||k.test(e)||Le.test(e)||Re.test(e)}var We=/^<([a-z][\w-]{0,31})>(?: #([^\s"]{1,64}))?(?: "([^"]{0,60})")?(?: in #(\S{1,64}))?$/,A=/^artifacts-component-root/,j=r(function({descriptor:e}){let t=We.exec(e);if(!t)return i("div",{className:"truncate text-xs text-muted",children:e});let[,n,r,a,o]=t,c=o&&!A.test(o)?o:void 0,l=i("span",{className:"inline-flex shrink-0 items-center rounded border bg-surface-1 px-1 font-mono text-[11px] text-secondary",children:n});return s("div",{className:"flex min-w-0 select-none items-center gap-1.5 text-xs text-muted",children:[a?i(re,{multiline:!0,content:i("span",{className:"line-clamp-3 break-words",children:`\u201C${a}\u201D`}),children:l}):l,r&&i("span",{className:"shrink-0 font-mono text-accent-pro-100",children:`#${r}`}),c&&i("span",{className:"shrink-0 truncate",children:i(_,{defaultMessage:"in <s>#{section}</s>",id:"6XJT5DKRek",values:{section:c,s:e=>i("span",{className:"font-mono text-secondary",children:e})}})})]})});function Ge(e,t,n){let r=We.exec(e.descriptor),i=r?.[1]??"",a=r?.[2]??"",o=r?.[4]??"",s=e.selector,c=s.replace(Ve,""),l=!t.descriptor&&a&&s!==`#${He(a)}`?`#${a} \u00B7 `:"",u=!t.descriptor&&o&&!s.startsWith(`#${He(o)} > `)?`in #${o} \u00B7 `:"",d=`${l}${u}${t.selector?s:c}`,f=`${l}${u}${s}`,p=c===""||c.startsWith("[")?[]:c.replace(/:nth-of-type\(\d+\)/g,"").split(" > "),m=p[0]?.startsWith("#")?p[0].slice(1):"",h=(m?p.slice(1):p).filter(e=>e!==":not(*)");return{tag:i,idPart:l,sectionPart:u,selectorLine:d,rawSelectorLine:f,show:d!==""&&(t.selector||n&&(m!==""||l!==""||u!=="")||c.startsWith("[")||h.some(e=>!Be.has(e))||/[\\]|[^ -~]/.test(s+a+o)||[m,a,o].some(e=>e.length>ze))}}function Ke(e,t){switch(e){case"p":return t.formatMessage({defaultMessage:"Paragraph",id:"qKqtMCzfla"});case"h1":case"h2":case"h3":case"h4":case"h5":case"h6":return t.formatMessage({defaultMessage:"Heading",id:"jT6/daUxjc"});case"button":return t.formatMessage({defaultMessage:"Button",id:"KP63fg1AMS"});case"a":return t.formatMessage({defaultMessage:"Link",id:"JBWS0clugK"});case"img":return t.formatMessage({defaultMessage:"Image",id:"+0zv6gS/c6"});case"li":return t.formatMessage({defaultMessage:"List item",id:"8zKBQnvxAY"});case"ul":case"ol":return t.formatMessage({defaultMessage:"List",id:"nOk9mhxGpU"});case"table":return t.formatMessage({defaultMessage:"Table",id:"IeBejt65iX"});case"td":case"th":return t.formatMessage({defaultMessage:"Cell",id:"/jd9eE01Ei"});case"input":case"textarea":case"select":return t.formatMessage({defaultMessage:"Field",id:"AbvQFbGv8I"});case"main":return t.formatMessage({defaultMessage:"Main",id:"EFTSMchYGh"});case"section":return t.formatMessage({defaultMessage:"Section",id:"q1Cd7mwNKK"});case"header":return t.formatMessage({defaultMessage:"Header",id:"79IWiafC91"});case"footer":return t.formatMessage({defaultMessage:"Footer",id:"Vge+RXo3fP"});case"nav":return t.formatMessage({defaultMessage:"Navigation",id:"fBg+7V6ZhY"});case"aside":return t.formatMessage({defaultMessage:"Sidebar",id:"JZy6joR+Wk"});case"article":return t.formatMessage({defaultMessage:"Article",id:"jx7Hn3QkH8"});case"form":return t.formatMessage({defaultMessage:"Form",id:"baRFiFaNBT"});case"label":return t.formatMessage({defaultMessage:"Label",id:"753yX5necH"});case"span":return t.formatMessage({defaultMessage:"Text",id:"aA8bDwsPeJ"});case"div":return t.formatMessage({defaultMessage:"Block",id:"Up5U7Ko8zq"});case"body":return t.formatMessage({defaultMessage:"Page",id:"wFmAFCPAci"});default:return null}}var M=16,qe=r(function({descriptor:e,x:t,y:n}){let r=We.exec(e),a=r?.[1]??e.slice(0,24),o=r?.[2],c=n<M;return s("div",{className:"pointer-events-none absolute z-20 max-w-[16rem] truncate px-1 py-px font-mono text-[10px] leading-[14px]",style:{left:t-1,top:c?n:n-M,backgroundColor:he,color:"#fff"},children:[a,o&&i("span",{style:{opacity:.8},children:` #${o}`})]})}),Je=r(function({n:e,active:t,swingIn:n=!1}){let r=m()??!1,a=h(!r&&(t||n)||t?-90:0,{stiffness:300,damping:22});o(()=>{r?a.jump(t?-90:0):a.set(t?-90:0)},[t,a,r]);let s=g(a,e=>-e);return i(d.div,{className:"flex size-6 items-center justify-center rounded-full rounded-bl-[2px]",style:{rotate:a,transformOrigin:"1px 23px",backgroundColor:t?he:"#fff",boxShadow:`0 0 0 1px ${t?ge:_e}, ${ve}`},children:e!==void 0&&i(d.span,{className:"text-[11px] font-semibold leading-none",style:{rotate:s,color:t?"#fff":"#141413"},children:e})})});function Ye(e,t){if(e.length!==t.length)return!1;for(let n=0;n<e.length;n++){let r=e[n],i=t[n];if(r.x!==i.x||r.y!==i.y||r.w!==i.w||r.h!==i.h)return!1}return!0}function Xe(e,t){if(e.size!==t.size)return!1;for(let[n,r]of t){let t=e.get(n);if(!t||t.found!==r.found||!Ye(t.lineRects,r.lineRects))return!1}return!0}function Ze(e,t){if(!e||e.size!==t.size)return!1;for(let[n,r]of t){let t=e.get(n);if(!t||t.x!==r.x||t.y!==r.y||t.found!==r.found)return!1}return!0}var Qe=[],N=r(function({active:r,token:m,documentRef:h,commentProps:g,uiHidden:ae=!1,commentMode:ue,onCommentModeChange:b,pageTextIndex:me,host:ge}){let S=ie(),{userContentRendererUrl:we}=u(),{containerRef:T,setKeyDownHandler:E}=ge,[Ne,D]=e(!1),[O,Fe]=e(null),[Ie,k]=e(null),Le=p(0),Re=p(0),ze=b!==void 0,[Ve,He]=e(!1),A=ze?ue??!1:Ve,j=t(e=>{b?b(e):He(e)},[b]),M=l(!1);o(()=>{M.current=A},[A]),o(()=>{rt.current=j},[j]);let N=l(null);o(()=>{let e=T.current;if(!e)return;let t=new ResizeObserver(([e])=>{N.current={w:e.contentRect.width,h:e.contentRect.height}});return t.observe(e),()=>t.disconnect()},[T]);let[P,et]=e(null),F=l(null);o(()=>{F.current=P},[P]);let tt=l(0),nt=l(void 0);o(()=>{nt.current=me===void 0?void 0:Me(me)},[me]);let rt=l(null),[it,at]=e(null),[ot,st]=e(null),[I,L]=e(null),[R,z]=e(null),B=l(!1),ct=l(null);o(()=>{B.current=R!==null,ct.current=R?.kind??null},[R]);let[V,lt]=e(""),[H,ut]=e(!1),[U,W]=e(null),[G,dt]=e(null),ft=l(0),K=l(!1);o(()=>{K.current=U!==null},[U]);let pt=n(()=>de(h),[h]),mt=h.kind==="file",ht=l(mt);o(()=>{ht.current=mt},[mt]);let q=g?.comments??Qe,J=n(()=>q.filter(e=>le(e)&&(e.status??"open")==="open"&&e.target.anchor.kind==="element"&&de(e.target.document)===pt),[q,pt]),gt=n(()=>oe(q),[q]),_t=n(()=>J.map(e=>{let t=e.target.anchor;return{id:e.id,selector:t.selector,pinX:t.pinX,pinY:t.pinY}}),[J]),vt=l(new Set);o(()=>{vt.current=new Set(_t.map(e=>e.id))},[_t]);let Y=n(()=>q.filter(e=>le(e)&&(e.status??"open")==="open"&&e.target.anchor.kind==="text-quote"&&e.id!=="__cwhr_draft"&&de(e.target.document)===pt).slice(0,Ce),[q,pt]),yt=n(()=>Y.map(e=>{let t=e.target.anchor;return{id:e.id,exact:y(t.exact.slice(0,pe)),prefix:y(t.prefix.slice(-32)),suffix:y(t.suffix.slice(0,32)),startOffset:Math.max(0,Math.trunc(Number(t.startOffset))||0)}}),[Y]),X=R?.kind==="text"?R.anchor:null,bt=n(()=>X?[...yt,{id:fe,exact:X.exact,prefix:X.prefix,suffix:X.suffix,startOffset:X.startOffset}]:yt,[yt,X]),xt=l(new Set);o(()=>{xt.current=new Set(bt.map(e=>e.id))},[bt]);let St=n(()=>[...J,...Y],[J,Y]),Ct=t(e=>{let t=e;if(!(!t||typeof t!="object")){if(t.type==="capture"){if(!M.current)return;if(B.current||K.current){F.current?.postMessage({type:"clearSelection"}),z(e=>e?.kind==="element"?null:e),W(null);return}let e=N.current?.w??600,n=N.current?.h??400,r=je(t.selector,1e3);if(!Pe.test(r)){F.current?.postMessage({type:"clearSelection"});return}let i=v(t.textHint,300),a=v(t.descriptor,400),o=i!==""&&(nt.current===void 0?i.length>60:!nt.current.includes(Me(i))),s=We.exec(a)?.[3]??"",c={text:o,descriptor:s!==""&&!i.startsWith(s)||a!==""&&!We.test(a),selector:Ue(r)};z({kind:"element",captureId:++ft.current,x:w(Number(t.clientX)||0,0,e),y:w(Number(t.clientY)||0,0,n),boundsW:e,boundsH:n,labelX:w(Number(t.rectLeft)||0,0,e),labelY:w(Number(t.rectTop)||0,0,n),anchor:{selector:r,textHint:i,descriptor:a,pinX:w(Number(t.pinX)||0,0,1),pinY:w(Number(t.pinY)||0,0,1)},suspect:c}),lt(""),ut(c.text||c.descriptor||c.selector),W(null),Fe(null),k(null)}else if(t.type==="rects"){if(!Array.isArray(t.rects))return;let e=Number(t.scrollY);if(Number.isFinite(e)&&e>=0&&(tt.current=e),at(e=>{let n=vt.current,r=Math.max(n.size*2,16),i=t.rects.length>r?t.rects.slice(0,r):t.rects,a=new Map;for(let e of i)typeof e?.id!="string"||!n.has(e.id)||a.set(e.id,{id:e.id,x:Number(e.x)||0,y:Number(e.y)||0,found:e.found===!0});return Ze(e,a)?e:a}),Array.isArray(t.quoteRects)){let e=xt.current,n=N.current??{w:600,h:400},r=t.quoteRects.slice(0,Math.max(e.size*2,16));st(t=>{let i=new Map;for(let t of r)typeof t?.id!="string"||!e.has(t.id)||i.set(t.id,{id:t.id,found:t.found===!0,lineRects:Ae(t.lineRects,n)});return t&&Xe(t,i)?t:i})}}else if(t.type==="dismiss"){if(K.current&&W(null),!M.current)return;B.current&&ct.current==="element"?(F.current?.postMessage({type:"clearSelection"}),z(null)):K.current||rt.current?.(!1)}else if(t.type==="clickAway")W(null);else if(t.type==="selRect"){if(!B.current||t.found!==!0)return;let e=Number(t.left),n=Number(t.top),r=Number(t.w),i=Number(t.h);if(!Number.isFinite(e)||!Number.isFinite(n)||!Number.isFinite(r)||!Number.isFinite(i))return;let a=N.current??{w:600,h:400};z(t=>{if(t?.kind!=="element")return t;let o=w(e+t.anchor.pinX*r,0,a.w),s=w(n+t.anchor.pinY*i,0,a.h);return o===t.x&&s===t.y?t:{...t,x:o,y:s,labelX:w(e,0,a.w),labelY:w(n,0,a.h)}})}else if(t.type==="cursor"){if(!M.current)return;let e=Number(t.x),n=Number(t.y);if(!Number.isFinite(e)||!Number.isFinite(n))return;let r=N.current??{w:600,h:400};if(e<0||n<0||e>r.w||n>r.h){D(!1),Fe(null);return}D(!0);let i=t.hover;Fe(e=>{if(!i||typeof i!="object")return e===null?e:null;let t={x:w(Number(i.x)||0,0,r.w),y:w(Number(i.y)||0,0,r.h),w:w(Number(i.w)||0,0,r.w),h:w(Number(i.h)||0,0,r.h)};return e&&e.x===t.x&&e.y===t.y&&e.w===t.w&&e.h===t.h?e:t})}else if(t.type==="textCapture"){if(!ht.current)return;let e=N.current??{w:600,h:400},n=ke(t.rect,e)??{x:0,y:0,w:0,h:0},r=Ae(t.lineRects,e),i=null;if(typeof t.exact=="string"){let e=y(t.exact.slice(0,pe)),n=Math.max(0,Math.trunc(Number(t.startOffset))||0),r=Math.max(0,Math.trunc(Number(t.endOffset))||0);e.length>0&&r-n===e.length&&(i={exact:e,prefix:y(typeof t.prefix=="string"?t.prefix.slice(-32):""),suffix:y(typeof t.suffix=="string"?t.suffix.slice(0,32):""),startOffset:n,endOffset:r})}L(e=>{let t=i??e?.anchor??null;return t?e&&e.anchor.exact===t.exact&&e.anchor.prefix===t.prefix&&e.anchor.suffix===t.suffix&&e.anchor.startOffset===t.startOffset&&e.anchor.endOffset===t.endOffset&&e.rect.x===n.x&&e.rect.y===n.y&&e.rect.w===n.w&&e.rect.h===n.h&&Ye(e.lineRects,r)?e:{rect:n,lineRects:r,anchor:t}:e})}else t.type==="textClear"&&L(null)}},[]),wt=l(Ct);o(()=>{wt.current=Ct},[Ct]),o(()=>{if(!m)return;let e=null;try{e=new URL(we).origin}catch{return}let t=t=>{if(t.origin!==e)return;let n=t.data;if(!n||n.type!=="__cowork_html_review_ready__"||n.token!==m)return;let r=t.ports[0];r&&(r.onmessage=e=>wt.current(e.data),et(r),at(null),st(null),L(null))};return window.addEventListener("message",t),()=>{window.removeEventListener("message",t)}},[m,we]),o(()=>()=>P?.close(),[P]),o(()=>{P?.postMessage({type:"mode",on:A})},[P,A]);let Tt=R!==null||U!==null;o(()=>{P?.postMessage({type:"composing",open:Tt})},[P,Tt]),o(()=>{P?.postMessage({type:"pins",pins:_t})},[P,_t]),o(()=>{P?.postMessage({type:"quotes",quotes:bt})},[P,bt]),o(()=>{P&&tt.current>0&&P.postMessage({type:"restoreScroll",y:tt.current})},[P]),o(()=>{R===null&&P?.postMessage({type:"clearSelection"})},[P,R]);let Et=A&&Ne&&!R&&!U,Dt=t(()=>{j(!A)},[A,j]),Ot=t(e=>{let t=T.current?.getBoundingClientRect();t&&(Le.set(w(e.clientX-t.left+12,C,Math.max(C,t.width-224-C))),Re.set(w(e.clientY-t.top+14,C,Math.max(C,t.height-80))))},[T,Le,Re]),kt=t(e=>{W(t=>t===e?null:e),z(e=>e?.kind==="text"?e:null),k(null)},[]),At=t(()=>W(null),[]),jt=t(()=>{if(!I?.anchor)return;if(v(I.anchor.exact,1e3)===""){L(null),F.current?.postMessage({type:"clearTextSel"});return}let e=N.current??{w:600,h:400};z({kind:"text",captureId:++ft.current,boundsW:e.w,boundsH:e.h,anchor:I.anchor,fallbackX:w(I.rect.x+I.rect.w/2,0,e.w),fallbackY:I.rect.y}),lt(""),ut(I.anchor.exact.length>60),W(null),L(null),F.current?.postMessage({type:"clearTextSel"})},[I]),Mt=R!==null;o(()=>{if(!A&&!Mt&&!U)return;let e=e=>{e.key!=="Escape"||e.defaultPrevented||e.isComposing||(e.preventDefault(),Mt||U?(z(null),W(null)):j(!1))};return window.addEventListener("keydown",e),()=>window.removeEventListener("keydown",e)},[A,Mt,U,j]);let Nt=t(e=>{e.key!=="Escape"||e.nativeEvent.isComposing||!M.current&&!B.current&&!K.current||(e.preventDefault(),e.stopPropagation(),B.current||K.current?(F.current?.postMessage({type:"clearSelection"}),z(null),W(null)):rt.current?.(!1))},[]);o(()=>(E(Nt),()=>E(null)),[E,Nt]),o(()=>{z(e=>e?.kind==="text"?e:null),W(null),!A&&ht.current&&(L(null),F.current?.postMessage({type:"clearTextSel"})),A||(D(!1),Fe(null),k(null))},[A]),o(()=>{k(e=>e&&!J.some(t=>t.id===e)&&!Y.some(t=>t.id===e)?null:e)},[J,Y]),o(()=>{dt(e=>e&&J.some(t=>!e.knownIds.has(t.id)&&it?.has(t.id))?null:e)},[J,it]),o(()=>{if(!G)return;let e=G.captureId,t=setTimeout(()=>{dt(t=>t?.captureId===e?null:t)},2500);return()=>clearTimeout(t)},[G]);let Pt=t(()=>{!R||!V.trim()||!g||(R.kind==="element"?(g.onCommentSubmit(ce(h,R.anchor),V.trim(),{displayMode:"rendered",forceNew:!0}),dt({captureId:R.captureId,x:R.x,y:R.y,knownIds:new Set(J.map(e=>e.id))})):g.onCommentSubmit(se(h,{...R.anchor,prefix:"",suffix:""}),V.trim(),{displayMode:"rendered",forceNew:!0}),z(null),lt(""))},[R,V,g,h,J]);if(o(()=>{(ae||!r)&&(j(!1),z(null),W(null),dt(null),L(null))},[ae,r,j]),o(()=>{z(null),lt(""),W(null),dt(null),L(null),st(null)},[pt]),!(r&&g&&!ae))return null;let Ft=U?St.find(e=>e.id===U):void 0,It=U?it?.get(U):void 0,Lt=U?ot?.get(U):void 0,Rt=Lt?.found?Lt.lineRects[0]:void 0,zt=Ie&&Ie!==U&&!R?St.find(e=>e.id===Ie):void 0,Bt=St.filter(e=>{let t=it?.get(e.id)??ot?.get(e.id);return t!==void 0&&!t.found}),Z=N.current?.w??600,Q=N.current?.h??400,$=ot?.get(fe),Vt=R?.kind==="text"?$?.found&&$.lineRects[0]?{x:w($.lineRects[0].x,0,Z),y:w($.lineRects[0].y+$.lineRects[0].h,0,Q)}:{x:R.fallbackX,y:R.fallbackY}:null,Ht=!A&&I!==null&&I.rect.w>0&&I.rect.h>0&&R===null&&U===null,Ut=R?.kind==="element"?{x:R.x,y:R.y}:Vt,Wt=R?.kind==="element"?R.anchor.textHint?`\u201C${R.anchor.textHint}\u201D`:"":R?v(R.anchor.exact,pe):"";return s(a,{children:[i("div",{className:c("absolute top-2 right-2 z-20",ze&&"hidden"),children:i("button",{type:"button","aria-pressed":A,onClick:Dt,className:c("rounded-md border px-3 py-1.5 text-sm font-medium shadow-md",A?"border-accent-pro-200 bg-fill-pro text-oncolor-100":"border-border-300 bg-surface-3 text-primary hover:bg-surface-1"),children:A?i(_,{defaultMessage:"Done commenting",id:"cXIcxYfeiJ"}):i(_,{defaultMessage:"Comment",id:"LgbKvU/n17"})})}),s("div",{className:"pointer-events-none absolute inset-0 z-10 overflow-hidden",children:[Et&&O&&i("div",{className:"pointer-events-none absolute",style:{left:O.x,top:O.y,width:O.w,height:O.h,border:`2px solid ${he}`}}),Y.map((e,t)=>{let n=ot?.get(e.id);if(!n?.found||n.lineRects.length===0)return null;let r=n.lineRects[0];return s("div",{className:"contents",children:[n.lineRects.map((e,t)=>i("div",{className:"pointer-events-none absolute",style:{left:e.x,top:e.y,width:e.w,height:e.h,backgroundColor:xe}},t)),i("button",{type:"button",className:"pointer-events-auto absolute bg-transparent",style:{left:w(r.x-1,0,Math.max(0,Z-x)),top:w(r.y-23,0,Math.max(0,Q-x))},onClick:()=>kt(e.id),onMouseEnter:t=>{Ot(t),k(e.id)},onMouseMove:Ot,onMouseLeave:()=>k(t=>t===e.id?null:t),"aria-label":S.formatMessage({defaultMessage:"Comment {number} on selected text",id:"c2nYJ59GyU"},{number:J.length+t+1}),children:i(Je,{n:J.length+t+1,active:U===e.id})})]},e.id)}),R?.kind==="text"&&$?.found&&$.lineRects.map((e,t)=>i("div",{className:"pointer-events-none absolute",style:{left:e.x,top:e.y,width:e.w,height:e.h,backgroundColor:Se}},`draft-${t}`)),J.map((e,t)=>{let n=it?.get(e.id);return!n||!n.found?null:i("button",{type:"button",className:"pointer-events-auto absolute bg-transparent",style:{left:w(n.x-1,0,Math.max(0,Z-x)),top:w(n.y-23,0,Math.max(0,Q-x))},onClick:()=>kt(e.id),onMouseEnter:t=>{Ot(t),k(e.id)},onMouseMove:Ot,onMouseLeave:()=>k(t=>t===e.id?null:t),"aria-label":S.formatMessage({defaultMessage:"Comment {number}",id:"BV8rl3I9dc"},{number:t+1}),children:i(Je,{n:t+1,active:U===e.id,swingIn:G!==null&&!G.knownIds.has(e.id)})},e.id)}),Bt.length>0&&i("div",{className:"pointer-events-auto absolute bottom-2 left-2 flex max-h-40 flex-col gap-1 overflow-y-auto",children:Bt.map(e=>i("button",{type:"button",className:"flex items-center gap-1.5 rounded-full border border-dashed bg-surface-3 px-2 py-0.5 text-xs text-secondary hover:bg-surface-1",onClick:()=>kt(e.id),children:i(_,{defaultMessage:"Detached comment",id:"//Wx7/3+2u"})},e.id))})]}),R?.kind==="element"&&R.anchor.descriptor&&i(qe,{descriptor:R.anchor.descriptor,x:R.labelX,y:R.labelY}),i(f,{children:Ht&&I&&i(d.button,{type:"button",initial:{opacity:0,y:8,scale:.9},animate:{opacity:1,y:0,scale:1},exit:{opacity:0,scale:.9,transition:{duration:.1}},transition:{duration:.18,ease:[.17,.84,.44,1]},className:"absolute z-30 flex size-7 items-center justify-center rounded-full rounded-bl-[2px]",style:{left:w(I.rect.x+I.rect.w/2-14,4,Math.max(4,Z-32)),top:w(I.rect.y-34,4,Math.max(4,Q-32)),backgroundColor:"#fff",boxShadow:`0 0 0 1px ${_e}, ${ve}`,transformOrigin:"1px 27px"},onClick:jt,"aria-label":S.formatMessage({defaultMessage:"Comment on selection",id:"FOrqFcMnhI"}),children:i(ne,{name:"ChatAdd",size:"sm"})})}),i(f,{children:((R?.kind==="element"?R:null)??G)&&i(d.div,{"aria-hidden":!0,className:"pointer-events-none absolute z-20 size-6 rounded-full rounded-bl-[2px]",initial:{rotate:R?.kind==="element"?0:-90,opacity:1},animate:{rotate:-90},exit:G?{opacity:0,transition:{duration:.05}}:{opacity:0,scale:.6},transition:{type:"spring",stiffness:260,damping:16},style:{left:w(((R?.kind==="element"?R.x:void 0)??G?.x??0)-1,0,Math.max(0,Z-x)),top:w(((R?.kind==="element"?R.y:void 0)??G?.y??0)-23,0,Math.max(0,Q-x)),transformOrigin:"1px 23px",backgroundColor:"#fff",boxShadow:`0 0 0 1px ${_e}, ${ve}`}},R?.captureId??G?.captureId)}),zt&&i(d.div,{initial:{opacity:0,scale:.98},animate:{opacity:1,scale:1},transition:be.transition,className:"pointer-events-none absolute left-0 top-0 z-30 w-56 rounded-xl bg-surface-3 p-3",style:{x:Le,y:Re,boxShadow:ye},children:i("div",{className:"line-clamp-4 whitespace-pre-wrap break-words text-[13px] leading-snug text-primary",children:zt.text})}),i(f,{children:R&&i(d.div,{drag:!0,dragMomentum:!1,dragConstraints:T,dragElastic:.05,initial:{scale:.25,opacity:0},animate:{scale:1,opacity:1},exit:{scale:.9,opacity:0},transition:{type:"spring",stiffness:420,damping:28},className:c("absolute z-30 flex w-64 cursor-grab flex-col gap-xs p-sm active:cursor-grabbing",te("popover")),style:{...Oe({x:Ut?.x??0,y:Ut?.y??0,boundsW:R.boundsW,boundsH:R.boundsH,estH:R.kind==="element"&&(H||R.anchor.textHint.length>60||Ge(R.anchor,R.suspect,H).show)?De:R.kind==="element"||H?Ee:Te}),transformOrigin:"0px 0px"},children:(()=>{let e=V.trim()!=="",t=e=>e.stopPropagation(),n=i("input",{autoFocus:!0,type:"text",className:"min-w-0 flex-1 cursor-text bg-transparent text-body text-primary outline-none placeholder:text-muted",value:V,"aria-label":S.formatMessage({defaultMessage:"Add a comment\u2026",id:"4oif0IPXeY"}),placeholder:S.formatMessage({defaultMessage:"Add a comment\u2026",id:"4oif0IPXeY"}),onPointerDownCapture:t,onChange:e=>lt(e.target.value),onKeyDown:e=>{e.nativeEvent.isComposing||(e.key==="Enter"?(e.preventDefault(),Pt()):e.key==="Escape"&&B.current&&(e.preventDefault(),e.stopPropagation(),z(null)))}}),r=i("div",{className:"scroll-fade-y scroll-fade-size-3 max-h-[4lh] min-w-0 flex-1 overflow-y-auto whitespace-pre-wrap break-words rounded text-caption text-muted outline-none [scrollbar-width:thin] focus-visible:shadow-focus","data-quote-text":"","data-forced-text":H?"":void 0,tabIndex:0,onPointerDownCapture:t,children:Wt}),o=S.formatMessage({defaultMessage:"Add comment",id:"eiaPxp89eC"}),l=r;if(R.kind==="element"){let{suspect:e}=R,{tag:n,idPart:a,sectionPart:o,selectorLine:u,rawSelectorLine:d,show:f}=Ge(R.anchor,e,H),p=n?Ke(n,S):null,m=n||y(R.anchor.descriptor.slice(0,12))||"?",h=n?`<${n}>`:"",g=u===""||u===n&&a===""&&o===""?h||m:[h,u].filter(Boolean).join(" \u00B7 "),te=S.formatMessage({defaultMessage:"Element context: {tag}",id:"5AVQs0KiSk"},{tag:p??m}),_=p!==null||n===""||Be.has(n);l=s("div",{className:"flex min-w-0 flex-1 flex-col",children:[s("div",{className:"flex min-w-0 flex-wrap items-start gap-x-xs",children:[i(re,{multiline:!0,content:i("span",{className:"break-all font-mono",children:g}),children:_?s(ee,{variant:"ghost",size:"xxs",flush:!0,"aria-label":te,"data-element-chip":"",onPointerDownCapture:t,children:[i("span",{className:"-ms-0.5 inline-flex",children:i(ne,{name:"Code",size:"auto-sm"})}),i("span",{"data-element-label":"",children:p??i("span",{className:"font-mono",children:m})})]}):i("button",{type:"button",className:"inline-flex min-w-0 max-w-full cursor-default select-none rounded text-left outline-none focus-visible:shadow-focus","aria-label":te,"data-element-chip":"",onPointerDownCapture:t,children:i("span",{className:"break-all font-mono text-caption font-medium text-secondary","data-element-label":"",children:m})})}),f&&i(re,{multiline:!0,content:i("span",{className:"break-all font-mono",children:d}),children:i("div",{className:c("scroll-fade-y scroll-fade-size-3 max-h-[4lh] min-w-32 flex-1 overflow-y-auto break-all rounded font-mono text-caption text-muted outline-none [scrollbar-width:thin] focus-visible:shadow-focus",p===null&&"basis-full"),"data-selector-line":"",tabIndex:0,onPointerDownCapture:t,children:u})})]}),H&&e.descriptor&&R.anchor.descriptor&&i("div",{className:"scroll-fade-y scroll-fade-size-3 max-h-[4lh] overflow-y-auto break-words rounded text-caption text-muted outline-none [scrollbar-width:thin] focus-visible:shadow-focus","data-raw-descriptor":"",tabIndex:0,onPointerDownCapture:t,children:R.anchor.descriptor}),Wt!==""&&r]})}return s(a,{children:[i("div",{className:"flex min-w-0 flex-col gap-xs rounded bg-alpha-1 px-sm py-xs",children:l}),s("div",{className:"flex items-center gap-xs pl-xs",children:[n,i("span",{className:"inline-flex shrink-0",onPointerDownCapture:t,children:i(ee,{size:"xs",variant:e?"primary":"ghost",disabled:!e,"aria-label":o,onPointerDownCapture:t,onClick:Pt,children:i(_,{defaultMessage:"Add",id:"2/2yg+qAwp"})})})]})]})})()},R.captureId)}),Ft&&i($e,{comment:Ft,replies:gt.get(Ft.id)??Qe,commentProps:g,x:w(It?.found?It.x+6:Rt?Rt.x+6:8,8,Math.max(8,Z-232)),y:w(It?.found?It.y+6:Rt?Rt.y+Rt.h+6:8,8,Math.max(8,Q-160)),onClose:At},Ft.id)]})});r(function({className:e,children:t,...n}){let{active:r,commentProps:a,uiHidden:o=!1}=n;return i(ae,{active:r,interactive:r&&!!a&&!o,className:e,layer:e=>i(N,{...n,host:e}),children:t})});var $e=r(function({comment:e,replies:t,commentProps:n,x:r,y:a,onClose:o}){let c=ie(),l=e.target.anchor,u=n.stagedIds?.has(e.id)??!1;return s(d.div,{...be,className:"absolute z-30 w-56 rounded-xl bg-surface-3 p-3",style:{left:r,top:a,boxShadow:ye},children:[i("div",{className:"whitespace-pre-wrap break-words text-[13px] leading-snug text-primary",children:e.text}),t.map(e=>i("div",{className:"mt-2 ml-2 border-l-2 pl-2 text-[13px] leading-snug text-secondary",children:e.text},e.id)),s("div",{className:"mt-2 flex min-w-0 items-center gap-1.5",children:[l.kind==="element"&&l.descriptor&&i(j,{descriptor:l.descriptor}),l.kind==="text-quote"&&i("div",{className:"truncate text-xs text-muted",children:`\u201C${v(l.exact,80)}\u201D`}),i("span",{className:"shrink-0 text-[11px] text-muted",children:new Date(e.createdAt).toLocaleTimeString(c.locale,{hour:"numeric",minute:"2-digit"})}),s("div",{className:"ml-auto flex shrink-0 items-center gap-0.5",children:[n.onSendToClaude&&!u&&i(re,{content:c.formatMessage({defaultMessage:"Send to Claude",id:"xGC0T/NxhG"}),children:i("button",{type:"button",className:"flex size-5 items-center justify-center rounded text-muted transition-colors hover:bg-surface-1 hover:text-primary",onClick:()=>{n.onSendToClaude?.(e.id),o()},"aria-label":c.formatMessage({defaultMessage:"Send to Claude",id:"xGC0T/NxhG"}),children:i(ne,{name:"ChatAdd",size:"sm"})})}),i("button",{type:"button",className:"flex size-5 items-center justify-center rounded text-muted transition-colors hover:bg-surface-1 hover:text-danger-100",onClick:()=>{n.onCommentDelete(e.id),o()},"aria-label":c.formatMessage({defaultMessage:"Delete comment",id:"wOZRKWT1/R"}),children:i(ne,{name:"Trash",size:"sm"})}),i("button",{type:"button",className:"flex size-5 items-center justify-center rounded text-muted transition-colors hover:bg-surface-1 hover:text-primary",onClick:o,"aria-label":c.formatMessage({defaultMessage:"Close",id:"rbrahOGMC3"}),children:i(ne,{name:"X",size:"sm"})})]})]})]})});export{N as HtmlPreviewReviewLayer,T as buildHtmlPreviewTextIndex,me as injectHtmlPreviewCommentGuest};import"./ca2ba6c7c-DZAuc2cR.js";