import{Fi as e}from"./shared-13-b3JLvuah.js";import{n as t}from"./ce80c609a-CnU5R4U-.js";var n="ui/resourceUri",r="ui://mcp-apps-example/hello-world.html",i="ui://mcp-apps-example/counter.html",a=`
    const app = (() => {
      let nextId = 1;

      return {
        sendRequest({ method, params }) {
          const id = nextId++;
          window.parent.postMessage({ jsonrpc: "2.0", id, method, params }, "*");
          return new Promise((resolve, reject) => {
            window.addEventListener("message", function listener(event) {
              const data = event.data;
              if (event.data?.id === id) {
                window.removeEventListener("message", listener);
                if (event.data?.result) {
                  resolve(event.data.result);
                } else if (event.data?.error) {
                  reject(new Error(event.data.error));
                }
              } else {
                reject(new Error(\`Unsupported message: \${JSON.stringify(data)}\`));
              }
            });
          });
        },
        sendNotification({ method, params }) {
          window.parent.postMessage({ jsonrpc: "2.0", method, params }, "*");
        },
        onNotification(method, handler) {
          window.addEventListener("message", function listener(event) {
            if (event.data?.method === method) {
              handler(event.data.params);
            }
          });
        },
        setupAutoResize() {
          new ResizeObserver(() => {
            const { body, documentElement: html } = document;
            const htmlStyle = getComputedStyle(html);

            // getBoundingClientRect returns fractional values (unlike scrollHeight)
            const rect = body.getBoundingClientRect();

            const width = Math.ceil(rect.width);
            const height = Math.ceil(
              rect.height +
              (parseFloat(htmlStyle.borderTop) || 0) +
              (parseFloat(htmlStyle.borderBottom) || 0)
            );

            this.sendNotification({
              method: "ui/notifications/size-changed",
              params: { width, height }
            });
          }).observe(document.body);
        },
      };
    })();
`;async function o(){let a=new t({name:"MCP Apps Example",version:"1.0.0"},{capabilities:{tools:{},resources:{}},jsonSchemaValidator:await e()});return a.setRequestHandler("tools/list",()=>({tools:[{name:"mcp_apps_hello",description:"Demonstrates MCP Apps - returns an interactive UI that greets the user",inputSchema:{type:"object",properties:{name:{type:"string",description:"Name to greet"}}},_meta:{[n]:r}},{name:"mcp_apps_counter",description:"Demonstrates MCP Apps with an interactive counter UI. The user can increment/decrement the counter.",inputSchema:{type:"object",properties:{initialValue:{type:"number",description:"Initial counter value",default:0}}},_meta:{[n]:i}}]})),a.setRequestHandler("tools/call",e=>{let{name:t,arguments:n}=e.params;if(t==="mcp_apps_hello"){let e=n?.name;return{content:[{type:"text",text:`Greeting: ${e?`Hello, ${e}!`:"Hello, World!"}. If your client supports MCP Apps, an interactive UI should have rendered.`}]}}return t==="mcp_apps_counter"?{content:[{type:"text",text:`Counter initialized to ${n?.initialValue??0}. If your client supports MCP Apps, an interactive counter UI should have rendered.`}]}:{content:[{type:"text",text:`Unknown tool: ${t}`}],isError:!0}}),a.setRequestHandler("resources/list",()=>({resources:[{uri:r,name:"Hello World MCP App",description:"Interactive greeting UI for the mcp_apps_hello tool",mimeType:"text/html;profile=mcp-app"},{uri:i,name:"Counter MCP App",description:"Interactive counter UI for the mcp_apps_counter tool",mimeType:"text/html;profile=mcp-app"}]})),a.setRequestHandler("resources/read",e=>{let{uri:t}=e.params;if(t===r)return{contents:[{uri:r,mimeType:"text/html;profile=mcp-app",text:s(),_meta:{ui:{csp:{resourceDomains:["https://unpkg.com"],connectDomains:["https://api.anthropic.com","https://bad-bunny.com"]},permissions:{clipboardWrite:{},microphone:{}}}}}]};if(t===i)return{contents:[{uri:i,mimeType:"text/html;profile=mcp-app",text:c()}]};throw Error(`Unknown resource: ${t}`)}),a}function s(){return`<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Hello World MCP App</title>
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      font-family: system-ui, -apple-system, sans-serif;
      padding: 1rem;
      background: transparent;
    }
    .container {
      max-width: 400px;
    }
    h1 {
      font-size: 1.25rem;
      margin-bottom: 0.75rem;
      color: #1a1a1a;
    }
    .greeting {
      font-size: 1.5rem;
      padding: 1rem;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      color: white;
      border-radius: 8px;
      text-align: center;
      margin-bottom: 1rem;
    }
    .input-row {
      display: flex;
      gap: 0.5rem;
      margin-bottom: 1rem;
    }
    input {
      flex: 1;
      padding: 0.5rem 0.75rem;
      border: 1px solid #ddd;
      border-radius: 6px;
      font-size: 0.875rem;
    }
    input:focus {
      outline: none;
      border-color: #667eea;
    }
    button {
      padding: 0.5rem 1rem;
      background: #667eea;
      color: white;
      border: none;
      border-radius: 6px;
      cursor: pointer;
      font-size: 0.875rem;
    }
    button:hover {
      background: #5a67d8;
    }
    .info {
      font-size: 0.75rem;
      color: #666;
    }
    .tool-input {
      margin-top: 1rem;
      padding: 0.75rem;
      background: #f5f5f5;
      border-radius: 6px;
      font-size: 0.75rem;
    }
    .tool-input pre {
      white-space: pre-wrap;
      word-break: break-all;
    }
  </style>
</head>
<body>
  <div class="container" id="app">
    <h1>Hello World MCP App</h1>
    <div class="greeting" id="greeting">Hello, World!</div>
    <div class="input-row">
      <input type="text" id="nameInput" placeholder="Enter a name..." />
      <button id="greetBtn">Greet</button>
    </div>
    <p class="info">Type a name and click Greet to update the greeting.</p>
    <div class="tool-input" id="toolInputDisplay" style="display: none;">
      <strong>Tool Input:</strong>
      <pre id="toolInputContent"></pre>
    </div>
  </div>

  <script type="module">
${a}
    const IMPLEMENTATION = { name: "Hello World App", version: "1.0.0" };

    // State
    let currentName = "World";

    // DOM elements
    const greetingEl = document.getElementById("greeting");
    const nameInput = document.getElementById("nameInput");
    const greetBtn = document.getElementById("greetBtn");
    const toolInputDisplay = document.getElementById("toolInputDisplay");
    const toolInputContent = document.getElementById("toolInputContent");

    // Update greeting
    function updateGreeting(name) {
      currentName = name || "World";
      greetingEl.textContent = "Hello, " + currentName + "!";
    }

    // Handle button click
    greetBtn.addEventListener("click", () => {
      updateGreeting(nameInput.value);
      nameInput.value = "";
    });

    // Handle enter key
    nameInput.addEventListener("keypress", (e) => {
      if (e.key === "Enter") {
        updateGreeting(nameInput.value);
        nameInput.value = "";
      }
    });

    // MCP App connection
    let nextRequestId = 1;

    async function connectToHost() {
      try {
        // Listen for messages from parent
        window.addEventListener("message", (event) => {
          try {
            const data = event.data;
            if (data && data.jsonrpc === "2.0") {
              // Handle initialize response - send initialized notification to complete handshake
              if (data.id === 1 && data.result) {
                const initializedNotification = {
                  jsonrpc: "2.0",
                  method: "ui/notifications/initialized",
                  params: {}
                };
                window.parent.postMessage(initializedNotification, "*");
              }
            }
          } catch (err) {
            console.error("[HelloWorldApp] Error handling message:", err);
          }
        });

        // Register notification handlers
        app.onNotification("ui/notifications/tool-input", (params) => {
          const args = params?.arguments || {};
          toolInputDisplay.style.display = "block";
          toolInputContent.textContent = JSON.stringify(args, null, 2);
          if (args.name) {
            updateGreeting(args.name);
          }
        });

        app.onNotification("ui/notifications/tool-result", (params) => {
          console.log("[HelloWorldApp] Tool result:", params);
        });

        app.onNotification("ui/notifications/host-context-changed", (params) => {
          console.log("[HelloWorldApp] Host context changed:", params);
        });

        // Send initialize request
        const initRequest = {
          jsonrpc: "2.0",
          id: nextRequestId++,
          method: "ui/initialize",
          params: {
            protocolVersion: "2025-11-21",
            appInfo: IMPLEMENTATION,
            appCapabilities: {}
          }
        };
        window.parent.postMessage(initRequest, "*");
        app.setupAutoResize();
      } catch (err) {
        console.error("[HelloWorldApp] Failed to connect:", err);
      }
    }

    // Connect when page loads
    connectToHost();
  <\/script>
</body>
</html>`}function c(){return`<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Counter MCP App</title>
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      font-family: system-ui, -apple-system, sans-serif;
      padding: 1rem;
      background: transparent;
    }
    .container {
      max-width: 300px;
      text-align: center;
    }
    h1 {
      font-size: 1.25rem;
      margin-bottom: 1rem;
      color: #1a1a1a;
    }
    .counter-display {
      font-size: 3rem;
      font-weight: bold;
      padding: 1.5rem;
      background: linear-gradient(135deg, #11998e 0%, #38ef7d 100%);
      color: white;
      border-radius: 12px;
      margin-bottom: 1rem;
      min-width: 150px;
      display: inline-block;
    }
    .buttons {
      display: flex;
      gap: 0.5rem;
      justify-content: center;
      margin-bottom: 1rem;
    }
    button {
      width: 50px;
      height: 50px;
      font-size: 1.5rem;
      border: none;
      border-radius: 50%;
      cursor: pointer;
      transition: transform 0.1s;
    }
    button:hover {
      transform: scale(1.1);
    }
    button:active {
      transform: scale(0.95);
    }
    .decrement {
      background: #ff6b6b;
      color: white;
    }
    .increment {
      background: #4ecdc4;
      color: white;
    }
    .reset {
      background: #95a5a6;
      color: white;
      font-size: 0.75rem;
      width: 60px;
      height: 30px;
      border-radius: 15px;
    }
    .info {
      font-size: 0.75rem;
      color: #666;
      margin-top: 0.5rem;
    }
  </style>
</head>
<body>
  <div class="container">
    <h1>Counter</h1>
    <div class="counter-display" id="counter">0</div>
    <div class="buttons">
      <button class="decrement" id="decrementBtn">-</button>
      <button class="increment" id="incrementBtn">+</button>
    </div>
    <button class="reset" id="resetBtn">Reset</button>
    <p class="info">Click the buttons to change the counter value.</p>
  </div>

  <script type="module">
${a}
    const IMPLEMENTATION = { name: "Counter App", version: "1.0.0" };

    // State
    let count = 0;
    let initialValue = 0;

    // DOM elements
    const counterEl = document.getElementById("counter");
    const incrementBtn = document.getElementById("incrementBtn");
    const decrementBtn = document.getElementById("decrementBtn");
    const resetBtn = document.getElementById("resetBtn");

    // Update display
    function updateDisplay() {
      counterEl.textContent = count;
      // Add color animation based on value
      if (count > 0) {
        counterEl.style.background = "linear-gradient(135deg, #11998e 0%, #38ef7d 100%)";
      } else if (count < 0) {
        counterEl.style.background = "linear-gradient(135deg, #ff6b6b 0%, #ee5a5a 100%)";
      } else {
        counterEl.style.background = "linear-gradient(135deg, #667eea 0%, #764ba2 100%)";
      }
    }

    // Update widget context with current counter value
    function updateWidgetContext() {
      app.sendRequest({
        method: "ui/update-model-context",
        params: {
          content: [
            {
              type: "text",
              text: "Counter is at " + count,
            },
          ],
        },
      }).catch((err) => {
        console.error("[CounterApp] Failed to update widget context:", err);
      });
    }

    // Event listeners
    incrementBtn.addEventListener("click", () => {
      count++;
      updateDisplay();
      updateWidgetContext();
    });

    decrementBtn.addEventListener("click", () => {
      count--;
      updateDisplay();
      updateWidgetContext();
    });

    resetBtn.addEventListener("click", () => {
      count = initialValue;
      updateDisplay();
      updateWidgetContext();
    });

    // MCP App connection
    let nextRequestId = 1;

    async function connectToHost() {
      try {
        // Listen for messages from parent
        window.addEventListener("message", (event) => {
          try {
            const data = event.data;
            if (data && data.jsonrpc === "2.0") {
              // Handle initialize response - send initialized notification to complete handshake
              if (data.id === 1 && data.result) {
                const initializedNotification = {
                  jsonrpc: "2.0",
                  method: "ui/notifications/initialized",
                  params: {}
                };
                window.parent.postMessage(initializedNotification, "*");
              }
            }
          } catch (err) {
            console.error("[CounterApp] Error handling message:", err);
          }
        });

        // Register notification handlers
        app.onNotification("ui/notifications/tool-input", (params) => {
          const args = params?.arguments || {};
          if (typeof args.initialValue === "number") {
            initialValue = args.initialValue;
            count = initialValue;
            updateDisplay();
          }
        });

        app.onNotification("ui/notifications/tool-result", (params) => {
          console.log("[CounterApp] Tool result:", params);
        });

        app.onNotification("ui/notifications/host-context-changed", (params) => {
          console.log("[CounterApp] Host context changed:", params);
        });

        // Send initialize request
        const initRequest = {
          jsonrpc: "2.0",
          id: nextRequestId++,
          method: "ui/initialize",
          params: {
            protocolVersion: "2025-11-21",
            appInfo: IMPLEMENTATION,
            appCapabilities: {}
          }
        };
        window.parent.postMessage(initRequest, "*");
        app.setupAutoResize();
      } catch (err) {
        console.error("[CounterApp] Failed to connect:", err);
      }
    }

    // Initialize
    updateDisplay();
    connectToHost();
  <\/script>
</body>
</html>`}export{o as getMcpAppsExampleServerInstance};import"./c78d94a49-E2MsznXZ.js";import"./c8bec64fe-DQxZ31w9.js";