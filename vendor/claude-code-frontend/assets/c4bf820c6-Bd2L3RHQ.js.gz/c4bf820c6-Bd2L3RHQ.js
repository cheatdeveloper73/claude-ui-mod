import"./c25d902c2-pfwcL43h.js";import"./c81ec8b86-CLPgPh0E.js";import{n as e}from"./cc8498a90-CpBEy0Vk.js";import"./c4f8ea596-9gDincPd.js";import"./c468f963e-oCQvAmqu.js";import"./cde226ffd-CPrsho0W.js";import"./c26ae3b21-DNPjo19t.js";import"./cbc5da31c-DJVOyUp4.js";import"./cfb90fcaf-D-SWXkqr.js";import"./c4fc55166-CfIP72ZG.js";import"./c85e960e9-DI9kIGPI.js";import"./ce63fa920-uN20h3Eh.js";import"./c4b0e7197-Cxjull9L.js";import"./c5e69fe3d-D2QSr5BG.js";import"./c508b0190-UxPTKRq-.js";import{r as t,t as n}from"./c288d2e54-B4VY1KvD.js";import"./cc4b74920-BMrB-W0m.js";var r=n({defaultLayout:"swimlane",styles:e(e=>`${t(e)}
  .swimlane.cluster rect {
    stroke: ${e.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,"getStyles")});export{r as diagram};import"./cc485d2ed-j3P6yWuy.js";