import{La as e,Sa as t,aa as n,ja as r,za as i}from"./vendor-frame-CvMkXlR3.js";import{Dc as a,bc as o,gc as s,kc as c}from"./shared-2-GB8sG9uX.js";var l=0,u=.3,d=.3,f=4/3,p=1,m=1,h=.25,g=.15,_=.2,v=.12,y=.8,b=1.1,x=.04,S=.005,C=.07,w=.006,T=.13,ee=.015,E=.11,D=.02,O=.15,k=24,A=50,j=150,M=300,N=.5,P=.3,F=.2,I=.75,L=3,R=.6,z=3500,te=1,B=.6,ne=.05,re=1,V=.1,H=.25,U=[2,4,8,12,16,20,24,28,32,36,40].map(e=>e*H);function W(){return`
  attribute vec2 aVertexPosition;
  uniform mat4 uModelViewMatrix;
  varying vec2 vPosition;

  void main(void) {
    vec2 normalizedPosition = aVertexPosition / ${u.toFixed(2)};
    gl_Position = uModelViewMatrix * vec4(aVertexPosition, 0.0, 1.0);
    vPosition = normalizedPosition;
  }
`}function ie(){return`
  precision highp float;
  varying vec2 vPosition;
  uniform vec4 uBaseColor;
  uniform float uOpacityFactor;
  uniform float uOvalRatio;

  void main(void) {
    vec2 ovalPos = vec2(vPosition.x / uOvalRatio, vPosition.y);
    float dist = length(ovalPos);

    // Hard edge with slight anti-aliasing at boundary
    float alpha = 1.0 - smoothstep(0.95, 1.0, dist);
    alpha *= ${R.toFixed(2)};
    alpha *= uBaseColor.a * uOpacityFactor;

    vec3 premultColor = uBaseColor.rgb * alpha;
    gl_FragColor = vec4(premultColor, alpha);
  }
`}function ae(){return`
  attribute vec2 aVertexPosition;
  attribute vec2 aTexCoord;
  varying vec2 vTexCoord;

  void main(void) {
    gl_Position = vec4(aVertexPosition, 0.0, 1.0);
    vTexCoord = aTexCoord;
  }
`}function G(){return`
  precision highp float;
  varying vec2 vTexCoord;
  uniform sampler2D uTexture;
  uniform vec2 uResolution;
  uniform float uOffset; // Kawase offset in texels of the sampled texture
  uniform float uTime;
  uniform float uIsLastPass; // 1.0 for final pass (apply noise), 0.0 otherwise

  float random(vec2 st) {
    return fract(sin(dot(st.xy, vec2(12.9898, 78.233))) * 43758.5453123);
  }

  void main(void) {
    vec2 texelSize = 1.0 / uResolution;

    // Kawase blur: sample 4 diagonal corners + center
    vec4 result = texture2D(uTexture, vTexCoord) * 4.0;
    result += texture2D(uTexture, vTexCoord + vec2(-uOffset, -uOffset) * texelSize);
    result += texture2D(uTexture, vTexCoord + vec2(-uOffset,  uOffset) * texelSize);
    result += texture2D(uTexture, vTexCoord + vec2( uOffset, -uOffset) * texelSize);
    result += texture2D(uTexture, vTexCoord + vec2( uOffset,  uOffset) * texelSize);
    vec4 blurred = result / 8.0;

    // Apply noise on final pass only
    ${`
    if (uIsLastPass > 0.5) {
      vec2 noiseCoord = gl_FragCoord.xy * 0.01;
      float animSpeed = ${k.toFixed(1)};
      float timeScale = floor(uTime * animSpeed) / animSpeed;

      float noise = 0.0;
      vec2 p1 = floor(noiseCoord * ${A.toFixed(1)}) + vec2(timeScale * 1.0, timeScale * 0.7);
      noise += random(p1) * ${N.toFixed(1)};
      vec2 p2 = floor(noiseCoord * ${j.toFixed(1)}) + vec2(timeScale * 0.5, timeScale * 1.3);
      noise += random(p2) * ${P.toFixed(1)};
      vec2 p3 = floor(noiseCoord * ${M.toFixed(1)}) + vec2(timeScale * 1.4, timeScale * 0.2);
      noise += random(p3) * ${F.toFixed(1)};

      float grainThreshold = ${I.toFixed(2)};
      float grainIntensity = ${O.toFixed(4)} * ${L.toFixed(1)};
      float grainMask = smoothstep(grainThreshold, 0.99, noise);
      vec3 grainColor = vec3(1.0) * grainMask * grainIntensity;

      // Only add noise where there's content (based on alpha)
      blurred.rgb += grainColor * blurred.a;
    }
    `}

    gl_FragColor = blurred;
  }
`}function K(e,t,n){let r=e.createFramebuffer(),i=e.createTexture();return!r||!i?{framebuffer:null,texture:null}:(e.bindTexture(e.TEXTURE_2D,i),e.texImage2D(e.TEXTURE_2D,0,e.RGBA,t,n,0,e.RGBA,e.UNSIGNED_BYTE,null),e.texParameteri(e.TEXTURE_2D,e.TEXTURE_MIN_FILTER,e.LINEAR),e.texParameteri(e.TEXTURE_2D,e.TEXTURE_MAG_FILTER,e.LINEAR),e.texParameteri(e.TEXTURE_2D,e.TEXTURE_WRAP_S,e.CLAMP_TO_EDGE),e.texParameteri(e.TEXTURE_2D,e.TEXTURE_WRAP_T,e.CLAMP_TO_EDGE),e.bindFramebuffer(e.FRAMEBUFFER,r),e.framebufferTexture2D(e.FRAMEBUFFER,e.COLOR_ATTACHMENT0,e.TEXTURE_2D,i,0),e.bindFramebuffer(e.FRAMEBUFFER,null),e.bindTexture(e.TEXTURE_2D,null),{framebuffer:r,texture:i})}function q(e){let t=e.createBuffer();e.bindBuffer(e.ARRAY_BUFFER,t),e.bufferData(e.ARRAY_BUFFER,new Float32Array([-1,-1,1,-1,1,1,-1,-1,1,1,-1,1]),e.STATIC_DRAW);let n=e.createBuffer();return e.bindBuffer(e.ARRAY_BUFFER,n),e.bufferData(e.ARRAY_BUFFER,new Float32Array([0,0,1,0,1,1,0,0,1,1,0,1]),e.STATIC_DRAW),{position:t,texCoord:n,vertexCount:6}}function oe(e){let t=Y(e,e.VERTEX_SHADER,ae()),n=Y(e,e.FRAGMENT_SHADER,G());if(!t||!n)return null;let r=X(e,t,n);return r?{program:r,attribLocations:{vertexPosition:e.getAttribLocation(r,"aVertexPosition"),texCoord:e.getAttribLocation(r,"aTexCoord")},uniformLocations:{texture:e.getUniformLocation(r,"uTexture"),resolution:e.getUniformLocation(r,"uResolution"),offset:e.getUniformLocation(r,"uOffset"),time:e.getUniformLocation(r,"uTime"),isLastPass:e.getUniformLocation(r,"uIsLastPass")}}:null}function J(e){let t=e.match(/rgba\((\d+),\s*(\d+),\s*(\d+),\s*([0-9.]+)\)/);return t?[parseInt(t[1])/255,parseInt(t[2])/255,parseInt(t[3])/255,parseFloat(t[4])]:[0,0,0,0]}function se(e,t,n){return[e[0]+(t[0]-e[0])*n,e[1]+(t[1]-e[1])*n,e[2]+(t[2]-e[2])*n,e[3]+(t[3]-e[3])*n]}function ce(e,t,n,r){let i=t.context.sampleRate/2,a=Math.floor(n/i*(e.length-1)),o=Math.floor(r/i*(e.length-1)),s=0;for(let t=a;t<=o;t++)s+=e[t];return s/((o-a+1)*255)}function Y(e,t,n){let r=e.createShader(t);return r?(e.shaderSource(r,n),e.compileShader(r),e.getShaderParameter(r,e.COMPILE_STATUS)?r:(e.deleteShader(r),null)):null}function X(e,t,n){let r=e.createProgram();return!r||(e.attachShader(r,t),e.attachShader(r,n),e.linkProgram(r),!e.getProgramParameter(r,e.LINK_STATUS))?null:r}function le(e){let t=e.createBuffer();e.bindBuffer(e.ARRAY_BUFFER,t);let n=u,r=n,i=[-.3,-.3,n,-.3,n,r,-.3,-.3,n,r,-.3,r];return e.bufferData(e.ARRAY_BUFFER,new Float32Array(i),e.STATIC_DRAW),{position:t,vertexCount:6}}var ue=/swiftshader|llvmpipe|softpipe|basic render driver|software/i;function Z(e){try{let t=e.getExtension("WEBGL_debug_renderer_info"),n=e.getParameter(t?t.UNMASKED_RENDERER_WEBGL:e.RENDERER);return typeof n=="string"&&ue.test(n)}catch{return!1}}var Q=null;function de(e,t,n,r,i={}){if(!e)return;let a=t=>{e.getAttachedShaders(t)?.forEach(t=>{e.deleteShader(t)}),e.deleteProgram(t)};try{r&&(e.deleteFramebuffer(r.framebuffer1),e.deleteFramebuffer(r.framebuffer2),e.deleteTexture(r.texture1),e.deleteTexture(r.texture2),e.deleteBuffer(r.quadBuffers.position),e.deleteBuffer(r.quadBuffers.texCoord),a(r.blurProgram.program)),n&&e.deleteBuffer(n.position),t&&a(t.program)}catch{}if(i.releaseContext)try{e.getExtension("WEBGL_lose_context")?.loseContext()}catch{}}function fe(){if(Q!==null)return Q;if(typeof document>"u")return!1;let e=null;try{if(e=document.createElement("canvas").getContext("webgl",{depth:!1,stencil:!1}),e===null)return!1;Q=!Z(e)}catch{Q=!1}finally{try{e?.getExtension("WEBGL_lose_context")?.loseContext()}catch{}}return Q??!1}function pe(e){let t=e.getContext("webgl",{alpha:!0,premultipliedAlpha:!0,antialias:!0,depth:!1,stencil:!1});if(!t||Z(t))return{gl:null,programInfo:null,buffers:null,blurResources:null};t.enable(t.BLEND),t.blendEquation(t.FUNC_ADD),t.blendFunc(t.ONE,t.ONE_MINUS_SRC_ALPHA),t.disable(t.DEPTH_TEST),t.clearColor(0,0,0,0);let n=Y(t,t.VERTEX_SHADER,W()),r=Y(t,t.FRAGMENT_SHADER,ie());if(!n||!r)return{gl:t,programInfo:null,buffers:null,blurResources:null};let i=X(t,n,r);if(!i)return{gl:t,programInfo:null,buffers:null,blurResources:null};let a={program:i,attribLocations:{vertexPosition:t.getAttribLocation(i,"aVertexPosition")},uniformLocations:{baseColor:t.getUniformLocation(i,"uBaseColor"),modelViewMatrix:t.getUniformLocation(i,"uModelViewMatrix"),opacityFactor:t.getUniformLocation(i,"uOpacityFactor"),ovalRatio:t.getUniformLocation(i,"uOvalRatio")}},o=le(t),s=null,c=oe(t),l=q(t),u=Math.max(1,Math.round(e.width*H)),d=Math.max(1,Math.round(e.height*H)),f=K(t,u,d),p=K(t,u,d);return c&&f.framebuffer&&f.texture&&p.framebuffer&&p.texture&&(s={blurProgram:c,framebuffer1:f.framebuffer,texture1:f.texture,framebuffer2:p.framebuffer,texture2:p.texture,width:u,height:d,quadBuffers:l}),{gl:t,programInfo:a,buffers:o,blurResources:s}}function me(e,t,n,r,i,a,o,s){let c=(o?.circleBaseY??l)+(o?.yShiftClip??0),u=i/1e3;s?(e.bindFramebuffer(e.FRAMEBUFFER,s.framebuffer1),e.viewport(0,0,s.width,s.height)):e.viewport(0,0,e.canvas.width,e.canvas.height),e.clearColor(0,0,0,0),e.clear(e.COLOR_BUFFER_BIT),e.blendFunc(e.ONE,e.ONE_MINUS_SRC_ALPHA),e.bindBuffer(e.ARRAY_BUFFER,n.position),e.vertexAttribPointer(t.attribLocations.vertexPosition,2,e.FLOAT,!1,0,0),e.enableVertexAttribArray(t.attribLocations.vertexPosition),e.useProgram(t.program),e.uniform4f(t.uniformLocations.baseColor,r[0],r[1],r[2],r[3]),e.uniform1f(t.uniformLocations.opacityFactor,1),o?.horizontalModeEnabled?e.uniform1f(t.uniformLocations.ovalRatio,p/f):e.uniform1f(t.uniformLocations.ovalRatio,p);for(let r=0;r<7;r++){let i;i=o?.horizontalModeEnabled?-.6/2+d*2*r/6:-1+r*2/6;let s=h+r*g,l=_+r*v,O=r*Math.PI*y,k=r*Math.PI*b,A=x+r*S,j=C+r*w,M=Math.sin(u*s+O)*A+Math.sin(u*T+r*1.3)*ee,N=Math.cos(u*l+k)*j+Math.cos(u*E+r*2.7)*D,P=1,F=1,I=1,L=p,R=o?.horizontalModeEnabled?m:p,z=0;if(a[r]!==void 0){let e=Math.min(a[r]/te,1);P=B+e*.7999999999999999*.2,F=B+e*.7999999999999999*1.5,I=ne+e**+re*.75,z=e*V,L=o?.horizontalModeEnabled?R/f:R}let H=o?.verticalScale??1,U=(c+N+z)*H+(1-H);e.uniform1f(t.uniformLocations.opacityFactor,I),e.uniform1f(t.uniformLocations.ovalRatio,L);let W=[P,0,0,0,0,F*H,0,0,0,0,1,0,i+M,U,0,1];e.uniformMatrix4fv(t.uniformLocations.modelViewMatrix,!1,W),e.drawArrays(e.TRIANGLES,0,n.vertexCount)}if(s){let{blurProgram:t,framebuffer1:n,texture1:r,framebuffer2:i,texture2:a,width:o,height:c,quadBuffers:l}=s,d=U;e.useProgram(t.program),e.disable(e.BLEND),e.bindBuffer(e.ARRAY_BUFFER,l.position),e.vertexAttribPointer(t.attribLocations.vertexPosition,2,e.FLOAT,!1,0,0),e.enableVertexAttribArray(t.attribLocations.vertexPosition),e.bindBuffer(e.ARRAY_BUFFER,l.texCoord),e.vertexAttribPointer(t.attribLocations.texCoord,2,e.FLOAT,!1,0,0),e.enableVertexAttribArray(t.attribLocations.texCoord),e.uniform2f(t.uniformLocations.resolution,o,c),e.uniform1f(t.uniformLocations.time,u),e.uniform1i(t.uniformLocations.texture,0);let f=r,p=i;for(let s=0;s<d.length;s++){let u=s===d.length-1;u&&(p=null),e.bindFramebuffer(e.FRAMEBUFFER,p),u?e.viewport(0,0,e.canvas.width,e.canvas.height):e.viewport(0,0,o,c),e.clear(e.COLOR_BUFFER_BIT),e.bindTexture(e.TEXTURE_2D,f),e.uniform1f(t.uniformLocations.offset,d[s]),e.uniform1f(t.uniformLocations.isLastPass,+!!u),e.drawArrays(e.TRIANGLES,0,l.vertexCount),u||(p===i?(f=a,p=n):(f=r,p=i))}e.enable(e.BLEND)}}var he="rgba(217, 119, 87, 1.0)",ge=.92,_e=.9,$=(z-85)/7,ve=t(({analyzer:e=null,color:t=he,horizontalModeEnabled:a=!0,circleBaseY:o,verticalOffsetPx:s=0,bottomOverhangRatio:c=0})=>{let l=i([0,0,0,0]),u=i([0,0,0,0]),d=i(.03);r(()=>{u.current=J(t)},[t]);let f=i(null),p=i(null),m=i(null),h=i(null),g=i(null),_=i(null),v=i(null);r(()=>(v.current!==null&&(clearTimeout(v.current),v.current=null),()=>{v.current=setTimeout(()=>{f.current?.isConnected||(de(m.current,h.current,g.current,_.current,{releaseContext:!0}),m.current=null,h.current=null,g.current=null,_.current=null)},0)}),[]);let y=i(null),b=i(0),x=i(null),S=i(Array.from({length:7},()=>0)),C=i(Array.from({length:7},()=>0)),w=()=>{let e=f.current;if(!e)return!1;let n=window.devicePixelRatio||1,r=e.getBoundingClientRect();e.width=r.width*n,e.height=r.height*n,b.current=r.height;let{gl:i,programInfo:a,buffers:o,blurResources:s}=pe(e);return!i||!a||!o?!1:(m.current=i,h.current=a,g.current=o,_.current=s,l.current=J(t),u.current=[...l.current],!0)},T=t=>{y.current||=t;let n=t-y.current,r=m.current,i=h.current,f=g.current;if(!l.current.every((e,t)=>Math.abs(e-u.current[t])<.001)){let e=se(l.current,u.current,d.current);l.current=[...e]}if(e){x.current||=new Uint8Array(e.frequencyBinCount),e.getByteFrequencyData(x.current);for(let t=0;t<7;t++){let n=85+t*$,r=n+$,i=ce(x.current,e,n,r);S.current[t]=ge*S.current[t]+.07999999999999996*i,C.current[t]=_e*C.current[t]+.09999999999999998*S.current[t],isFinite(S.current[t])||(S.current[t]=0),isFinite(C.current[t])||(C.current[t]=0)}}if(r&&i&&f){let e=1/(1+c);me(r,i,f,l.current,n,C.current,{horizontalModeEnabled:a,circleBaseY:o,yShiftClip:b.current>0?-(2*s)/(b.current*e):0,verticalScale:e},_.current)}p.current=requestAnimationFrame(T)};return n("canvas",{ref:e=>{if(!e){p.current&&=(cancelAnimationFrame(p.current),null);return}f.current=e,!(!m.current&&!w())&&(p.current||=requestAnimationFrame(T))},className:"absolute left-0 top-0 w-full pointer-events-none",style:{height:`${(1+c)*100}%`},"aria-hidden":"true"})}),ye="rgba(106, 155, 204, 1.0)",be=.4,xe=t(t=>{let{verticalOffsetPx:r=0,bottomOffsetPx:i=0}=t,l=a(),u=o(),d=c(),f=s(),p=d.status!=="speaking",m=p?u??l:l,h=p?ye:void 0;return e(()=>!f||fe(),[f])?n("div",{"data-testid":"voice-audio-visualizer",className:"absolute bottom-0 left-1/2 -translate-x-1/2 z-0 pointer-events-none transition-opacity duration-500",style:{width:"150%",aspectRatio:"4 / 1",contain:"layout",opacity:+!!f,...i?{bottom:i}:null},children:f&&n(ve,{analyzer:m,color:h,horizontalModeEnabled:!0,circleBaseY:-.2,verticalOffsetPx:r,bottomOverhangRatio:be})}):null});export{xe as VoiceAudioVisualizer};