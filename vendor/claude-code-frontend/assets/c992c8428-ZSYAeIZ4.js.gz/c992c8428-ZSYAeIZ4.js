import{Ba as e,Ia as t,Sa as n,aa as r,ia as i,ja as a,oa as o,za as s}from"./vendor-frame-CvMkXlR3.js";import{Xy as c}from"./shared-common-0-BGMEEQm3.js";import{Ln as l,ra as u,wo as d}from"./shared-frame-DdWfvW_D.js";var f=`#version 300 es
in vec2 a_position;
out vec2 v_uv;
uniform vec2 u_resolution;
void main() {
  // pixel-space UV so fragment can do floor(uv / gap) without aspect distortion
  v_uv = (a_position * 0.5 + 0.5) * u_resolution;
  gl_Position = vec4(a_position, 0.0, 1.0);
}
`,p=`#version 300 es
precision highp float;
uniform vec2 u_resolution;
uniform float u_time;
uniform vec3 u_fg;   // hot ink (INKS.hot) \u2014 the brightest thing in the bar
uniform vec3 u_fg2;  // cool ink (INKS.cool) \u2014 the low-energy end of
                     // the ramp: luminous lavender in light, white in dark \u2014
                     // ALWAYS brighter than the ground it sits on, so every
                     // recruited cell reads as emitting, not as ink
uniform float u_seed; // re-rolled every press \u2014 fresh jitter and recruitment each run

// Burst ring buffer. Each slot is a one-shot burst: time it fired (in the
// u_time clock) and the origin in framebuffer pixels. Slots start far in the
// past so nothing plays on mount; old bursts age out via the cutoff below.
const int MAX_BURSTS = 8;
uniform float u_burstTime[MAX_BURSTS];
uniform vec2  u_burstCenter[MAX_BURSTS];
uniform float u_burstGain[MAX_BURSTS];   // strength k \u2208 [0,1] \u2014 first stop \u2192 0, top stop \u2192 1


// Master envelope: 1 while pressed, eased to 0 after release so the whole
// field cools down on mouse-up instead of trailing per-burst afterglows.
uniform float u_fade;

// The charged surface, folded into the same texture: a left-edge\u2192handle
// gradient (u_charge0 \u2192 u_charge1) that lives in the same cells as the
// energy and arrives with the same wavefront, so surface and energy read as
// one thing on one clock. u_pos is the handle fraction (0..1). The colors
// carry their token's alpha \u2014 light runs it opaque (the charge is the
// field's own ground there), and a transparent token would remove the
// surface entirely while the cells still paint.
uniform float u_pos;
uniform vec4 u_charge0;
uniform vec4 u_charge1;

// How much of the charged surface paints in the GAPS between cells (0..1).
// Light mode runs this high so the charge reads as a continuous dark ground
// for the bright cells to emit against; dark mode keeps 0 \u2014 its charge stays
// cell-masked exactly as before.
uniform float u_bedFill;

// Per-cell hue scatter (alpha channel = mix amount): a minority of cells
// lean toward each tint so the field reads rich instead of monochrome.
// Amount 0 (dark mode) leaves the ink ramp bit-identical.
uniform vec4 u_tintA; // accent blue lean
uniform vec4 u_tintB; // pink lean

in vec2 v_uv;
out vec4 fragColor;

// \u2500\u2500\u2500 the grid \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500
// The bar is a field of small rounded cells \u2014 a grid / activity-heatmap
// visual language, packed denser for intricacy inside a 24px bar. At rest it is invisible \u2014 only energy makes it exist.
const float CELL_PITCH = 4.0;  // px between cell centers (cell + gap) \u2014 nominal; the
                               // grid re-derives the exact pitch so rows tile the bar height
const float CELL_SIZE  = 3.0;  // px square
const float CELL_R     = 0.9;  // corner radius, px

// \u2500\u2500\u2500 the energy \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500
// A burst is a wavefront racing outward from the press point in Manhattan
// distance, quantized to whole cells: each cell flips on as the front reaches
// it (per-cell jitter keeps the front ragged and alive), then cools back down
// through the discrete ramp behind it.
//
// Per-burst strength k (u_burstGain) slides speed, reach, brightness and
// afterglow between the _LO (faint stop) and _HI (full blast) ends.
const float SPEED_LO   = 20.0;  // wavefront speed, cells/sec
const float SPEED_HI   = 36.0;  //   full blast crosses the bar in well under 2s
const float RANGE_LO   = 10.0;  // a faint pulse stays local to the handle, cells
const float RANGE_HI   = 55.0;  //   the full blast carries to the far end of the fill
const float DENSITY_LO = 0.30;  // fraction of cells a faint pulse recruits \u2014 sparse sketch
const float DENSITY_HI = 0.85;  //   full blast is busy but keeps dark gaps
const float JITTER     = 0.10;  // per-cell arrival scatter, sec \u2014 the organic part
const float HEAD_GAIN  = 1.25;  // arrival flash strength
const float HEAD_DECAY = 5.0;   // arrival flash fade, 1/s (fast)
const float BODY_GAIN  = 0.65;  // afterglow strength
const float BODY_LO    = 3.3;   // afterglow fade for the faint stop, 1/s \u2014 quick cool-down
const float BODY_HI    = 0.77;  //   full blast lingers ~1.3s behind the front
const float AMP_LO     = 0.55;  // overall brightness of the faintest stop
const float MAX_AGE    = 5.0;   // past this a slot is dead \u2014 skip the math

// \u2500\u2500\u2500 the rendering (discrete ramp + breathing top step) \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500
// Cell intensity quantizes to a 5-step ramp (never a continuous gradient),
// the ink walks from the cool ink toward the hot ink as the step rises \u2014
// energy always reads brighter than its ground \u2014 and only top-step cells
// breathe: slow, shallow, per-cell phase so neighbours never sync up (the app
// grid's own pulse). Defaults dialed in on
// shader-explorations/grid/03-cellular-ripple.html, then packed denser.
const float RAMP_POW    = 1.4;   // ink ramp curve \u2014 keeps the cool end longer
const float INK_MAX     = 0.85;  // historical ink ceiling \u2014 now the dark-mode value of u_inkCeil
const float BREATH_DIP  = 0.28;  // top-step breath depth
const float BREATH_BASE = 2.4;   // breath period floor, sec
const float BREATH_VARY = 1.4;   // per-cell period spread, sec
// Charged-surface shape, per mode (see u_bedFill/u_tint* for the rest of the
// mode split). Dark keeps the original constants (0.85 ceiling, 1.1 ramp \u2014
// a tint that deepens linearly toward the handle); light runs the ceiling to
// 1 with a much flatter ramp so the bed reads as a solid dark ground across
// the energized region, fading only at its left edge.
uniform float u_chargeMax;   // alpha ceiling of the charged surface at the handle
uniform float u_chargeRamp;  // exponent on the left-edge\u2192handle deepening

// Alpha of the LOWEST ramp step (the top step is u_inkCeil). Dark keeps the
// original 0.08 \u2014 over a dark fill with additive blending, alpha IS
// brightness, so the climb from 0.08 reads as the intensity ramp. Light
// raises the floor so every recruited cell paints near-solid and the
// intensity ramp is carried by the ink COLOR (lavender \u2192 white-hot) \u2014 a
// translucent chip over the vibrant bed would just read as bed.
uniform float u_inkFloor;

// Alpha of the TOP ramp step. Dark pins the historical INK_MAX (0.85 \u2014
// under additive blending a fully-opaque white cell blows out); light runs
// it to 1.0 so the sparse hot minority genuinely sparkles against the
// field's darker ground (measured headroom: hot cells capped at 0.61 luma
// over a 0.28 ground with the shared ceiling).
uniform float u_inkCeil;

// Multiplier on quantized cell energy. The per-cell brightness lottery is
// tuned for dark's additive regime, where even a faint white cell sparkles;
// in light's opaque regime the same distribution never reaches the hot end
// of the ink ramp, so light boosts it to put a white-hot minority on the
// board. Dark pins 1 \u2014 identical output.
uniform float u_energyGain;

float hash21(vec2 p) {
  return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
}

void main() {
  // Fit a whole number of rows into the bar height so no row is clipped at
  // the edges; cells stay square, so the right edge (hidden under the
  // handle / rounded end) absorbs any fractional column instead.
  float pitch = u_resolution.y / max(round(u_resolution.y / CELL_PITCH), 1.0);
  float cellScale = pitch / CELL_PITCH;
  vec2 cell = floor(v_uv / pitch);
  vec2 cellCenter = (cell + 0.5) * pitch;

  // Rounded-rect cell mask, anti-aliased \u2014 the gaps between cells never paint.
  float cellHalf = CELL_SIZE * 0.5 * cellScale;
  float cellR = CELL_R * cellScale;
  vec2 q = abs(v_uv - cellCenter) - vec2(cellHalf - cellR);
  float distC = length(max(q, vec2(0.0))) + min(max(q.x, q.y), 0.0) - cellR;
  float aa = min(fwidth(v_uv.x), 1.5);
  float cellMask = 1.0 - smoothstep(-aa, aa, distC);
  // Gaps can only exit early when the charged surface is strictly
  // cell-masked (u_bedFill 0); a continuous bed must keep painting them.
  if (cellMask <= 0.0 && u_bedFill <= 0.0) {
    fragColor = vec4(0.0);
    return;
  }

  float jitter = (hash21(cell + 41.7 + u_seed) - 0.5) * 2.0 * JITTER;
  float vary   = 0.35 + 0.65 * hash21(cell + 13.7 + u_seed); // some cells catch much brighter than others

  float energy = 0.0;
  float charged = 0.0;
  for (int i = 0; i < MAX_BURSTS; i++) {
    float age = u_time - u_burstTime[i];
    if (age < 0.0 || age > MAX_AGE) continue;
    float k = clamp(u_burstGain[i], 0.0, 1.0);

    vec2 originCell = floor(u_burstCenter[i] / pitch);
    float manh = abs(cell.x - originCell.x) + abs(cell.y - originCell.y);

    // Gentle falloff so the field carries to the ends of the revealed bar at
    // full blast instead of dying out mid-bar.
    float range   = mix(RANGE_LO, RANGE_HI, k);
    float falloff = exp(-manh / (range * 0.85));
    float reach   = exp(-max(manh - range, 0.0) * 0.12);
    float speed   = mix(SPEED_LO, SPEED_HI, k);
    float t = age - manh / speed - jitter;
    // The charged surface arrives with the same front: once any burst has
    // reached this cell it stays charged for as long as the press lives.
    charged = max(charged, smoothstep(0.0, 0.15, t) * reach);
    if (t < 0.0) continue;

    // The recruitment lottery re-rolls per burst (the burst's own timestamp
    // is part of the ticket), so every pulse lights a different subset of
    // cells \u2014 a held press keeps tracing new patterns instead of re-lighting
    // the same ones. The lottery only gates the bright energy cells; the
    // charged surface below recruits every cell the front reaches.
    float rank = hash21(cell + 7.3 + u_seed + u_burstTime[i]);
    if (rank > mix(DENSITY_LO, DENSITY_HI, k)) continue;

    float head = HEAD_GAIN * exp(-t * HEAD_DECAY);
    float body = BODY_GAIN * exp(-t * mix(BODY_LO, BODY_HI, k));
    energy += (head + body) * mix(AMP_LO, 1.0, k) * falloff * reach * vary;
  }


  // The master envelope scales energy BEFORE quantization, so on release the
  // whole field cools down through the ramp instead of fading in place. The
  // per-cell brightness lottery is applied here too \u2014 after saturation \u2014 so
  // it spreads cells across the whole ramp instead of being washed out once
  // energy pegs: most cells sit dim-to-mid, a minority run hot, the darkest
  // stay barely lit. Skew (pow) pushes the distribution toward dark.
  // Each cell drifts between two personal brightness identities on its own
  // slow, randomly-phased cycle, so which cells read bright or dark keeps
  // redistributing \u2014 the mosaic never freezes into a fixed pattern.
  float lumA = hash21(cell + 8.8 + u_seed);
  float lumB = hash21(cell + 88.8 + u_seed);
  float lumDrift = 0.5 + 0.5 * sin(u_time * 0.35 + lumA * 6.2832);
  float lum = pow(mix(lumA, lumB, lumDrift), 1.9);
  // A faint coherent wave keeps drifting right\u2192left between pulses, with a
  // touch of per-cell phase scatter so it reads as current, not as a bar.
  float stream = 0.9 + 0.16 * sin(u_time * 1.3 + cell.x * 0.45 + lumB * 2.0);
  float e = clamp(energy, 0.0, 1.0) * u_fade * mix(0.16, 1.0, lum) * stream
    * u_energyGain;

  // The charged surface: a left-edge\u2192handle gradient living in the same
  // cells, revealed by the same wavefront and the same envelope. Deeper
  // toward the handle; nothing where the front hasn't reached.
  float g = clamp(v_uv.x / max(u_pos * u_resolution.x, 1.0), 0.0, 1.0);
  vec3 chargeColor = mix(u_charge0.rgb, u_charge1.rgb, g);
  // The bed factor lets the charge spill into the gaps (light mode's
  // continuous dark ground) while the cells still sit a notch deeper, so the
  // grid stays legible inside the bed without bright gap-lines cutting it up.
  float bedMask = mix(u_bedFill, 1.0, cellMask);
  float chargeA = u_chargeMax * pow(g, u_chargeRamp) * charged * u_fade
    * bedMask * mix(u_charge0.a, u_charge1.a, g);

  // Discrete 5-step ramp for the energy on top \u2014 never a continuous gradient.
  // Empty at rest: energy IS visibility.
  float lv = step(0.04, e) + step(0.2, e) + step(0.4, e) + step(0.6, e) + step(0.8, e);
  // Linear alpha climb from the mode's floor \u2014 every step participates, so
  // the right-to-left intensity progression reads in both modes.
  float alpha = lv <= 0.0 ? 0.0 : mix(u_inkFloor, u_inkCeil, (lv - 1.0) / 4.0);

  // Only the hottest cells breathe \u2014 slow, shallow, never in unison.
  if (lv >= 5.0) {
    float period = BREATH_BASE + BREATH_VARY * hash21(cell + 3.1 + u_seed);
    float phase = hash21(cell + 5.5 + u_seed) * 6.2832;
    alpha *= 1.0 - BREATH_DIP * 0.5 * (1.0 + sin(u_time * 6.2832 / period + phase));
  }

  // Energy over charge (premultiplied), on a transparent canvas \u2014 the slider
  // fill shows through wherever neither paints.
  vec3 ink = mix(u_fg2, u_fg, pow(lv / 5.0, RAMP_POW));
  // Hue scatter: each cell draws a stable lottery ticket; the top of the
  // range leans blue, the bottom leans pink, the middle keeps the base
  // purple ramp. Tint alphas of 0 bypass this entirely.
  float hueSel = hash21(cell + 27.9 + u_seed);
  ink = mix(ink, u_tintA.rgb, u_tintA.a * smoothstep(0.62, 0.95, hueSel));
  // Pink leans the bottom of the range. Written as an inverted forward
  // smoothstep (1 - smoothstep(0.05, 0.38, \u2026)) rather than a descending one
  // (smoothstep(0.38, 0.05, \u2026)): GLSL leaves smoothstep undefined when
  // edge0 >= edge1, and a NaN here would survive the alpha-0 multiply in dark
  // mode and corrupt the ink. The polynomial's S(1-t) = 1-S(t) symmetry makes
  // this form bit-identical to the intended descending ramp.
  ink = mix(ink, u_tintB.rgb, u_tintB.a * (1.0 - smoothstep(0.05, 0.38, hueSel)));
  float eA = alpha * cellMask;
  vec3 col = ink * eA + chargeColor * chargeA * (1.0 - eA);
  float a = eA + chargeA * (1.0 - eA);
  if (a <= 0.0) {
    fragColor = vec4(0.0);
    return;
  }
  fragColor = vec4(col, a);
}
`;function m(e,t,n){let r=e.createShader(t);return r?(e.shaderSource(r,n),e.compileShader(r),r):null}function h(e,t,n){let r=m(e,e.VERTEX_SHADER,t),i=m(e,e.FRAGMENT_SHADER,n);if(!r||!i)return null;let a=e.createProgram();return a?(e.attachShader(a,r),e.attachShader(a,i),e.linkProgram(a),e.deleteShader(r),e.deleteShader(i),a):null}function ee(e){let t=e.createElement("canvas");t.width=1,t.height=1;let n=t.getContext("2d",{willReadFrequently:!0}),r="#010203";return e=>{if(!n||(n.fillStyle=r,n.fillStyle=e,n.fillStyle===r&&e.trim().toLowerCase()!==r))return null;n.clearRect(0,0,1,1),n.fillRect(0,0,1,1);let t=n.getImageData(0,0,1,1).data;return[(t[0]??0)/255,(t[1]??0)/255,(t[2]??0)/255,(t[3]??0)/255]}}var te=4147200,ne=new Float32Array([-1,-1,1,-1,-1,1,-1,1,1,-1,1,1]),g=8,re=5,ie=.7,ae=.85,oe=1.6;ie*1e3,ae*1e3;var _={light:{chargedStart:"#888edd",chargedEnd:"#8964c4",cool:"#c6c0f3",hot:"#fbedf1",tintBlue:"rgba(191, 214, 243, 0.28)",tintPink:"rgba(240, 188, 204, 0.28)"},dark:{chargedStart:"color(srgb 0.62 0.5 0.92)",chargedEnd:"color(srgb 0.35 0.25 0.6)",cool:"#ffffff",hot:l.text.pro.cssVar,tintBlue:"transparent",tintPink:"transparent"}},se={light:{bedFill:1,chargeMax:.92,chargeRamp:.5,inkFloor:.28,inkCeil:1,gain:1.18},dark:{bedFill:0,chargeMax:.85,chargeRamp:1.1,inkFloor:.08,inkCeil:.85,gain:1}};function v(e,t,n,r,i){let a=[],o=(e,t)=>{a.length>=8&&a.shift(),a.push([e,t])},s={pressStart:e=>{o("pressStart",e)},pressEnd:e=>{o("pressEnd",e)}};t.current=s;let c=!1,l=0,u=()=>{let o=e.getContext("webgl2",{alpha:!0,antialias:!1,depth:!1,stencil:!1});if(!o){t.current=null,i(!1);return}let s=o.getExtension("KHR_parallel_shader_compile"),u=h(o,f,p);if(!u){o.isContextLost()||(t.current=null,i(!1));return}let _=()=>{o.useProgram(u);let s=o.createBuffer();o.bindBuffer(o.ARRAY_BUFFER,s),o.bufferData(o.ARRAY_BUFFER,ne,o.STATIC_DRAW);let d=o.getAttribLocation(u,"a_position");o.enableVertexAttribArray(d),o.vertexAttribPointer(d,2,o.FLOAT,!1,0,0);let f=o.getUniformLocation(u,"u_time"),p=o.getUniformLocation(u,"u_resolution"),m=o.getUniformLocation(u,"u_seed"),h=o.getUniformLocation(u,"u_pos"),_=o.getUniformLocation(u,"u_charge0"),v=o.getUniformLocation(u,"u_charge1"),y=o.getUniformLocation(u,"u_bedFill"),b=o.getUniformLocation(u,"u_chargeMax"),x=o.getUniformLocation(u,"u_chargeRamp"),S=o.getUniformLocation(u,"u_inkFloor"),C=o.getUniformLocation(u,"u_inkCeil"),w=o.getUniformLocation(u,"u_energyGain"),ce=o.getUniformLocation(u,"u_tintA"),le=o.getUniformLocation(u,"u_tintB"),ue=o.getUniformLocation(u,"u_fg"),de=o.getUniformLocation(u,"u_fg2"),T=o.getUniformLocation(u,"u_burstTime[0]"),E=o.getUniformLocation(u,"u_burstCenter[0]"),fe=o.getUniformLocation(u,"u_burstGain[0]"),D=o.getUniformLocation(u,"u_fade");o.clearColor(0,0,0,0),o.uniform3fv(ue,[.72,.59,1]),o.uniform3fv(de,[1,1,1]),o.uniform1f(D,0),o.uniform1f(m,0),o.uniform1f(h,1),o.uniform4f(_,.62,.5,.92,1),o.uniform4f(v,.35,.25,.6,1),o.uniform1f(y,0),o.uniform1f(b,.85),o.uniform1f(x,1.1),o.uniform1f(S,.08),o.uniform1f(C,.85),o.uniform1f(w,1),o.uniform4f(ce,0,0,0,0),o.uniform4f(le,0,0,0,0);let O=new Float32Array(g).fill(-1e3),k=new Float32Array(16),pe=new Float32Array(g);o.uniform1fv(T,O),o.uniform2fv(E,k),o.uniform1fv(fe,pe);let A=0,j=!1;l=0;let M=0,N=0,P=e.ownerDocument,F=P.defaultView??window,me=F.requestAnimationFrame.bind(F),he=F.cancelAnimationFrame.bind(F),I=!0,L=1,R=1,z=(t,n,r)=>{let i=Math.max(1,t),a=Math.max(1,n);if(i!==L||a!==R){let e=i/L,t=a/R;for(let n=0;n<g;n++)k[n*2]*=e,k[n*2+1]*=t;o.uniform2fv(E,k),L=i,R=a,I=!0}let s=Math.max(1,Math.round(t*r)),c=Math.max(1,Math.round(n*r)),l=s*c;if(l>te){let e=Math.sqrt(te/l);s=Math.max(1,Math.round(s*e)),c=Math.max(1,Math.round(c*e))}(e.width!==s||e.height!==c)&&(e.width=s,e.height=c,I=!0)},B=0,V=-1,H=0,U=!1,W=-1/0,G=-1/0,ge=.45;c=!1;let K=(e,t)=>Math.min((.15+.7*e)*(.45+.55*t),1),q=()=>{I&&=(o.viewport(0,0,e.width,e.height),o.uniform2f(p,L,R),!1),o.uniform1f(f,B),o.uniform1f(h,Math.max(l,.02)),o.clear(o.COLOR_BUFFER_BIT),o.drawArrays(o.TRIANGLES,0,6)},_e=()=>B-W<re,ve=e=>{let t=V<0?0:Math.max(0,(e-V)*.001);if(B+=t,V=e,M=j?Math.min(M+t/ie,1):Math.max(M-t/ae,0),N=j?N+t:0,j&&B-W>ge){let e=Math.min(N/oe,1);ge=.3+Math.random()*.45,Oe(K(l,e)*(.85+Math.random()*.3),l+(Math.random()-.5)*.08)}let n=M*M*(3-2*M);o.uniform1f(D,n),q(),(j||_e()&&M>0)&&!P.hidden?H=me(ve):U=!1},J=()=>{U||(U=!0,V=-1,H=me(ve))},ye=()=>{U&&(U=!1,he(H))},be=new(F.ResizeObserver??ResizeObserver)(t=>{let n=t[0],r=n.devicePixelContentBoxSize?.[0];if(r){let e=F.devicePixelRatio||1;z(r.inlineSize/e,r.blockSize/e,e)}else{let t=n.borderBoxSize?.[0]??n.contentBoxSize?.[0],r=t?.inlineSize??e.clientWidth,i=t?.blockSize??e.clientHeight;z(r,i,F.devicePixelRatio||1)}q()});be.observe(e);let Y=F.matchMedia("(prefers-reduced-motion: reduce)"),X=typeof document>"u"?null:document.documentElement,Z=()=>Y.matches||X?.getAttribute("data-reduce-motion")==="true",xe=()=>{j=!1,W=-1/0,G=-1/0,M=0,O.fill(-1e3),o.uniform1fv(T,O),ye(),o.uniform1f(D,0),q()},Se=()=>{$(),j=!0,N=0,Oe(K(l,0),l)},Ce=()=>{P.hidden?xe():c&&!j&&!Z()?Se():_e()&&J()};P.addEventListener("visibilitychange",Ce);let we=()=>{P.hidden||(Z()?(j||U)&&xe():c&&!j&&Se())};Y.addEventListener("change",we);let Te=null;X&&(Te=new MutationObserver(we),Te.observe(X,{attributes:!0,attributeFilter:["data-reduce-motion"]}));let Q=()=>{j&&($(),U||q())},Ee=new F.MutationObserver(Q);Ee.observe(P.documentElement,{attributes:!0,attributeFilter:["data-mode"],subtree:!0});let De=F.matchMedia("(prefers-color-scheme: dark)");De.addEventListener("change",Q),r.current=Q,i(!0);let Oe=(e,t)=>{O[A]=B,k[A*2]=t*L,k[A*2+1]=R*(.35+Math.random()*.3),pe[A]=e,A=(A+1)%g,o.uniform1fv(T,O),o.uniform2fv(E,k),o.uniform1fv(fe,pe),W=B,G=F.performance.now(),P.hidden||J()},ke=null,$=()=>{ke??=ee(e.ownerDocument);let t=F.getComputedStyle(e),r=(e,t)=>ke?.(e)??t,i=r(t.color,[.72,.59,1,1]),a=r(t.outlineColor,[1,1,1,1]);o.uniform3f(ue,i[0],i[1],i[2]),o.uniform3f(de,a[0],a[1],a[2]),o.uniform4f(_,...r(t.borderTopColor,[.62,.5,.92,1])),o.uniform4f(v,...r(t.borderBottomColor,[.35,.25,.6,1])),o.uniform4f(ce,...r(t.textDecorationColor,[0,0,0,0])),o.uniform4f(le,...r(t.columnRuleColor,[0,0,0,0]));let s=t.colorScheme??"",c=se[s.includes("dark")?"dark":s.includes("light")?"light":n()];o.uniform1f(y,c.bedFill),o.uniform1f(b,c.chargeMax),o.uniform1f(x,c.chargeRamp),o.uniform1f(S,c.inkFloor),o.uniform1f(C,c.inkCeil),o.uniform1f(w,c.gain)};t.current={pressStart:e=>{c=!0,l=e,!Z()&&($(),F.performance.now()-G>5e3&&M<=0&&(O.fill(-1e3),o.uniform1fv(T,O),o.uniform1f(m,Math.random()*512)),j=!0,N=0,Oe(K(e,0),e))},pressEnd:e=>{c=!1,j&&(j=!1,l=e,P.hidden||J())}},z(e.clientWidth||1,e.clientHeight||1,F.devicePixelRatio||1),q();for(let[e,n]of a)t.current?.[e](n);return a.length=0,()=>{t.current=null,r.current=null,i(!1),ye(),be.disconnect(),Ee.disconnect(),De.removeEventListener("change",Q),Y.removeEventListener("change",we),Te?.disconnect(),P.removeEventListener("visibilitychange",Ce),o.deleteProgram(u),o.deleteBuffer(s)}},v=()=>{if(!o.getProgramParameter(u,o.LINK_STATUS)){o.deleteProgram(u),m=null,o.isContextLost()||(t.current=null,a.length=0,i(!1));return}m=_()};if(!s){v();return}let b=()=>{if(y=0,x=void 0,o.getProgramParameter(u,s.COMPLETION_STATUS_KHR)===!0){v();return}S()},S=()=>{e.ownerDocument.hidden?x=setTimeout(b,64):y=d.requestAnimationFrame(b)};m=()=>{y!==0&&d.cancelAnimationFrame(y),x!==void 0&&clearTimeout(x),o.deleteProgram(u)},S()},d=e.ownerDocument.defaultView??window,m=null,_=0,v=0,y=0,b,x;e.ownerDocument.hidden?b=setTimeout(u,0):_=d.requestAnimationFrame(()=>{v=d.requestAnimationFrame(u)});let S=!1,C=e=>{if(S||t.current===null)return;S=!0,e.preventDefault();let n=t.current!==s&&c,r=l;m?.(),m=null,t.current=s,c=!1,l=0,n&&o("pressStart",r)},w=()=>{S&&(S=!1,u())};return e.addEventListener("webglcontextlost",C),e.addEventListener("webglcontextrestored",w),()=>{e.removeEventListener("webglcontextlost",C),e.removeEventListener("webglcontextrestored",w),d.cancelAnimationFrame(_),d.cancelAnimationFrame(v),b!==void 0&&clearTimeout(b),t.current=null,m?.()}}function y({actionsRef:e,mode:n,onLiveChange:i,className:o}){let l=s(null),u=c(()=>n),d=s(null);a(()=>{d.current?.()},[n]);let f=c(e=>{i?.(e)});t(()=>{(l.current?.ownerDocument.defaultView??window).WebGL2RenderingContext===void 0&&f(!1)},[f]),a(()=>{let t=l.current;if(t)return v(t,e,u,d,f)},[e,u,f]);let p=_[n];return r("canvas",{ref:l,className:o??"absolute inset-0 w-full h-full pointer-events-none",style:{color:p.hot,outlineColor:p.cool,borderTopColor:p.chargedStart,borderBottomColor:p.chargedEnd,textDecorationColor:p.tintBlue,columnRuleColor:p.tintPink,borderWidth:0,borderStyle:"none"},"aria-hidden":!0})}var b={outer:"bg-surface-3",inner:"bg-alpha-2"},x=n(function({lit:t,base:n=b}){let a=d(),s=u(),[c,l]=e(null),[f]=e(t),[p,m]=e(t);t&&!p&&m(!0);let h=t&&!s&&(c===!0||c===null&&f);return o(i,{children:[r("span",{className:`absolute inset-0 ${n.outer} ${h?"opacity-100":"opacity-0"}`,style:{transition:s||c===!1?"none":h?"opacity 700ms ease-out":"opacity 850ms linear"},children:n.inner?r("span",{className:`absolute inset-0 ${n.inner}`}):null}),r("span",{className:"absolute inset-0 [mask-image:linear-gradient(to_right,transparent_0%,black_45%)] dark:[mask-image:linear-gradient(to_right,transparent_0%,black_60%)] dark:mix-blend-plus-lighter dark:opacity-65",children:p&&r(S,{lit:t,mode:a,onLiveChange:l})})]})});function S({lit:e,mode:t,onLiveChange:n}){let i=s(null);return a(()=>{if(e)return i.current?.pressStart(1),()=>i.current?.pressEnd(1)},[e]),r(y,{actionsRef:i,mode:t,onLiveChange:n})}export{x as t};